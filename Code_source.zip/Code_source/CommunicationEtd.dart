
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:projet_pfe/authentifierEtudiant.dart';
import 'DevoirEtd.dart';

import 'DocumetEtd.dart';
import 'message_etd.dart';
import 'package:intl/intl.dart';


// ignore: must_be_immutable
class CommunicationEtd extends StatefulWidget {
  // const CommunicationEtd({super.key});
  String list_module;
  static String modules_name = "";
  static String ID_Devoir="";
  static String prof = "";
  CommunicationEtd({required this.list_module}) {}
  @override
  State<CommunicationEtd> createState() => _CommunicationEtdState(list_module);
}

String list_module = "";

class _CommunicationEtdState extends State<CommunicationEtd>
       {
     Uint8List? file;
 
  
  String list_module;
  _CommunicationEtdState(this.list_module);
  List<String> modules = []; //les personnes ayant un modules
  
  String contenu="";
   final contenu_controller=TextEditingController();
 
  ScrollController sc = ScrollController();
    List ComptesRendus=[];

//////////////////////////////////affichr le modules
  Future getModule() async {
    final documentSnapshot = await FirebaseFirestore.instance
        .collection('Module')
        .doc(list_module)
        .get();
    final data = documentSnapshot.data();

    if (data != null && data.containsKey("nom_module")) {
      setState(() {
       CommunicationEtd. modules_name = (data["nom_module"]);
      });
    }
    print("nom module");
    print( CommunicationEtd.modules_name);
  }

  
  List<String> messages = [];
  Future message_envoie() async {
    CollectionReference chatCollection =
        FirebaseFirestore.instance.collection('messages');
    chatCollection.add({
      'contenu': contenu,
      'expediteur':authentifierEtudiant.email_input , //email_input
      'timestamp': DateTime.now(),
      'type': "text",
      "module" : CommunicationEtd.modules_name
    });
  
  }
  Future getProfEtud() async {
    await FirebaseFirestore.instance
        .collection("Professeur")
        .where("Modules", arrayContains: list_module)
        .get()
        .then((QuerySnapshot querySnapshot1) {
      querySnapshot1.docs.forEach((doc1) {
        print(doc1.get("email"));
       CommunicationEtd. prof = doc1.get("email");
        setState(() {
          modules.add(doc1.get("email"));
        });
      });
    });

    await FirebaseFirestore.instance
        .collection("Etudiant")
        .where("Modules", arrayContains: list_module)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        print(doc.get("email"));
        setState(() {
          modules.add(doc.get("email"));
        });
      });
    });
  }

  void main1() async {
    //  await getpro();
    getModule();
    await getProfEtud();
  }

  @override
  void initState() {
    
    super.initState();

 
    main1();
  }

 
 
  String messag = "";
  String type = "";

  Timestamp time = Timestamp(2, 3);

 int index = 0;
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 3,
        child: Scaffold(
            appBar: AppBar(
              toolbarHeight: 60,
              centerTitle: false,
              titleSpacing: 30,
              title: Text(
                CommunicationEtd. modules_name,
                style: TextStyle(
                    letterSpacing: 3,
                    fontFamily: 'Merienda-VariableFont_wght',
                    fontWeight: FontWeight.bold,
                    fontSize: 25,
                    color: Color.fromARGB(255, 255, 255, 255)),
              ),
              backgroundColor: Color.fromARGB(255, 63, 78, 215),
              bottom: TabBar(
                   onTap: (value) {
                  setState(() {
                    index = value;
                  });
                },
                tabs: [
                Tab(
                  icon: Icon(
                    Icons.chat,
                    color: Colors.white,
                    size: 20,
                  ),
                  text: 'Discussions',
                ),
                Tab(
                  icon: Icon(
                    Icons.animation_sharp,
                    color: const Color.fromARGB(255, 255, 255, 255),
                  ),
                  text: 'Travaux',
                ),
                Tab(
                  icon: Icon(
                    Icons.group_outlined,
                    color: Colors.white,
                  ),
                  text: 'Participants',
                ),
              ]),
            ),
            body: TabBarView(
              children: [
                //chno aytektebb fch t cliquer ela tabs bar

                Column(
                  children: [
                    Expanded(
                      child: StreamBuilder(
                          stream: FirebaseFirestore.instance
                              .collection("messages")
                              .orderBy("timestamp")
                              .snapshots(),
                          builder: (context, snapshot) {
                             if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                            List<dynamic> emailList = [];
                           List<dynamic> emailExp = [];
                             List<DateTime> datesList = [];
                            if (snapshot.hasData) {
                              final lis = snapshot.data?.docs;
                              for (var i in lis!) {
                                for(int j=0;j<modules.length;j++) {

                                if (modules[j] == i.data()["expediteur"] && CommunicationEtd. modules_name==i.data()["module"]) {
                                  Timestamp timestamp = i.data()["timestamp"];

                                  DateTime dateTime = timestamp.toDate();

                                  emailList.add(i.data()['contenu']);
                                 
                                  datesList.add(dateTime);
                                  emailExp.add(i.data()["expediteur"] );
                                }
                              }
                              }
 
                                   

                            }
                            if (emailList.isNotEmpty) {
                               WidgetsBinding.instance.addPostFrameCallback((_) {
  sc.animateTo(
    sc.position.maxScrollExtent,
    duration: const Duration(milliseconds: 10),
    curve: Curves.easeOut,
  );
});

                              return ListView.builder(controller: sc,
                                itemCount: emailList.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return Container(
                                    padding: EdgeInsets.all(25),
                                    width: 400,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 15),
                                    decoration: BoxDecoration(
                                        color:
                                            Color.fromARGB(255, 255, 255, 255),
                                        border: Border.all(
                                            color: Color.fromARGB(72, 14, 13, 13),),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(30),
                                            topRight: Radius.circular(30),
                                            bottomLeft: Radius.circular(30))),
                                    child: Column(
                                      children: [
                                         Container(alignment: Alignment.centerLeft,
                                                  child:emailExp[index]==CommunicationEtd.prof ?
                                                   Text(emailExp[index],style: TextStyle(color: Colors.red,fontWeight: FontWeight.bold))
                                                   : Text(emailExp[index],style: TextStyle(color: Color.fromARGB(255, 17, 156, 40),fontWeight: FontWeight.bold))
                                                   ),
                                        Center(
                                          child: Text(
                                            emailList[index],
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        Container(
                                            alignment: Alignment.bottomLeft,
                                            child: Center(
                                              child: Text(
                                                "\n" +
                                                    DateFormat('dd-MM-yyyy  HH:mm')
                                                        .format(datesList[index]),
                                              ),
                                            )),
                                      ],
                                    ),
                                  );
                                  
                                },
                              );
                            }
                            return Container();
                          }),
                    ),
                    Container(
                      child: _chat(),
                    )
                  ],
                ),

        ///////////////////////////////TAB2 //////////////////////////////////////////
   Column(
                     mainAxisSize: MainAxisSize.min,
                     children: [
                      Container(padding: EdgeInsets.only(top: 100,left: 10,right: 10),
                      child: ElevatedButton(onPressed: () {
                         Navigator.push(
                                               context,
                                               MaterialPageRoute(
                                builder: (context) => DevoirEtd()
                                ));
                      }, 
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 57, 209, 255),
                       padding: EdgeInsets.only(left: 80,right: 80,top: 20,bottom: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))
                      ),
                      child: Text("Devoir",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      ),
                      ),
                      Container(padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                      child: ElevatedButton(onPressed: () {
                           Navigator.push(
                                               context,
                                               MaterialPageRoute(
                                builder: (context) => DocumentEtd()
                                ));
                      }, 
                        style: ElevatedButton.styleFrom(
                         
                          backgroundColor:  Colors.green,
                        padding: EdgeInsets.only(left: 40,right: 40,top: 20,bottom: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40))
                      ),
                      child: Text("Document de cours",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      ),
                      )
                     
                     ],
                     ),

               
//////////////////Tab3/////////////////////////////////////////////////////////////

                ListView(
                  children: [
                    for (int i = 0; i < modules.length; i++)
                      /////A discuter////////////
                      GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        (message_etd(modules: modules[i]))));
                          },
                          /////A discuter////////////
                          child: StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection("messages")
                                  .orderBy('timestamp', descending: true)
                                  .snapshots(),
                              builder: (context, snapshot) {
                                if (!snapshot.hasData) {}
                                if (snapshot.connectionState ==
                                    ConnectionState.waiting) {
                             //     return CircularProgressIndicator(); // Indicateur de chargement en attendant les données
                                }
                                if (snapshot.hasData &&
                                    snapshot.data!.docs.isNotEmpty) {
                                  final data = snapshot.data?.docs;
                                  final list = [];
                                  if (data != null && data.first.exists) {
                                    for (var i1 in data) {
                                      if (authentifierEtudiant.email_input ==
                                                  i1.data()["expediteur"] &&
                                              modules[i] ==
                                                  i1.data()["recepteur"] ||
                                          authentifierEtudiant.email_input ==
                                                  i1.data()["recepteur"] &&
                                              modules[i] ==
                                                  i1.data()["expediteur"]) {
                                        messag = i1.data()['contenu'];
                                        type = i1.data()['type'];
                                        time = i1.data()['timestamp'];
                                        list.add(messag);
                                        list.add(type);
                                        list.add(time);
                                      } else {
                                        messag = "";
                                      }
                                    }

                                    if (list.isNotEmpty) {
                                      messag = list[0];
                                      type = list[1];
                                      time = list[2];
                                    }
                                    ;
                                    //   print(messag);
                                    print(type);
                                  }
                                } else {
                                  Text("");
                                }
                                
                                return Card(
                                  child: ListTile(
                                    
                                    leading:
                                    modules[i]==CommunicationEtd.prof ? 
                                     CircleAvatar(
                                  backgroundColor: Colors.red,   
                                      child: 
                                      Text( 
                                       modules[i]
                                            .substring(0, 1)
                                            .toUpperCase(),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,color: const Color.fromARGB(255, 255, 255, 255)),
                                      )
                                                                       ):
                                     CircleAvatar(
                                     
                                      backgroundColor: Color.fromARGB(255, 21, 211, 46),
                                      child: 
                                      Text( 
                                       modules[i]
                                            .substring(0, 2)
                                            .toUpperCase(),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,color: const Color.fromARGB(255, 255, 255, 255)),
                                      )
                                    ),
                                  
                                    title:modules[i]==CommunicationEtd.prof ? 
                                    Text(
                                      modules[i],
                                      style: TextStyle(fontSize: 16,color:  Colors.deepOrange,fontWeight: FontWeight.bold),
                                    ):
                                    Text(
                                      modules[i],
                                      style: TextStyle(fontSize: 15,color: Color.fromARGB(141, 19, 19, 19),fontWeight: FontWeight.bold),
                                    ),
                                    subtitle: type == "text" && messag != ""
                                        ? Row(
                                            children: [
                                              Expanded(child: Text(messag)),
                                              Text(DateFormat('HH:mm')
                                                  .format(time.toDate()))
                                            ],
                                          )
                                        : type == "image" && messag != ""
                                            ? Row(
                                                children: [
                                                  Expanded(
                                                      child: Row(
                                                    children: [
                                                      Text("photo"),
                                                      Icon(Icons.photo),
                                                    ],
                                                  )),
                                                  Text(DateFormat('HH:mm')
                                                      .format(time.toDate()))
                                                ],
                                              )
                                            : type == "document" && messag != ""
                                                ? Row(
                                                    children: [
                                                      Expanded(
                                                        child: Row(
                                                          children: [
                                                            Text("document"),
                                                            Icon(Icons
                                                                .picture_as_pdf_outlined),
                                                          ],
                                                        ),
                                                      ),
                                                      Text(DateFormat('HH:mm')
                                                          .format(
                                                              time.toDate()))
                                                    ],
                                                  )
                                                : Container(),
                                                
                                  ),
                                  
                                );
                              })),
                  ],
                ),
              ],
            ),


            )
            );
  }

//////////////////////////////////////////////////////
  Widget _chat() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2.1, vertical: 20),
      child: Row(
        children: [
          Expanded(
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              child: Row(
                children: [
                  Padding(padding: EdgeInsets.only(left: 30)),
                  Expanded(
                      child: TextField(controller: contenu_controller,
                    onChanged: (value) {
                       contenu = value;
                    },

                    keyboardType: TextInputType.multiline, //retour a la  ligne
                    maxLines: null,
                    decoration: InputDecoration(
                        hintText: "Partagez à votre classe ...",
                        border: InputBorder.none),
                  )),
                ],
              ),
            ),
          ),
          ////buton envoyer
          ///
          MaterialButton(
              onPressed: () {
                /*if (contenu.isEmpty) {
                print("vide");
              } else {
                message_envoie();
              }*/
              if(contenu.isNotEmpty) {
              message_envoie();
               contenu_controller.clear();
              }
              },
              minWidth: 0,
              // padding: EdgeInsets.only(left: 32),

              color: Color.fromARGB(210, 19, 225, 225),
              child: Text(
                "publier",
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
    );
  }
}
