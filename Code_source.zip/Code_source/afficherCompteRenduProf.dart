


import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';

import 'package:flutter/material.dart';

import 'package:path_provider/path_provider.dart';


import 'CommunicationEtd.dart';

import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import 'package:awesome_dialog/awesome_dialog.dart';

import 'CommunicationProf.dart';
// ignore: must_be_immutable
class afficherCompteRenduProf extends StatefulWidget {
//  const afficherCompteRendu({super.key});
 String nom_fichier;
 afficherCompteRenduProf({required this.nom_fichier}) {}
  @override
  State<afficherCompteRenduProf> createState() => _afficherCompteRenduProfState(nom_fichier);
}
String nom_fichier="";
int nb_devoir=0;
class _afficherCompteRenduProfState extends State<afficherCompteRenduProf> {
  String nom_fichier;
  _afficherCompteRenduProfState(this.nom_fichier);
  PdfViewerController? _pdfViewerController;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("La liste des comptes rendus",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 22,fontFamily: 'Merienda-VariableFont_wght'),),
      toolbarHeight: 80,
      backgroundColor: Colors.green,
      ),
    body:  StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Compte_Rendu")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailLis = [];
                    List<dynamic> Nom_fichie = [];
                    List<dynamic> emailExp = [];
                   var lis = snapshot.data?.docs ?? [];
                     if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      
                      
                      for (var i in lis) {
                           
                              
                  if(CommunicationProf.modules_name==i.data()["Module"] && nom_fichier==i.data()["ID_Devoir"]) {
                          emailLis.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom Compte Rendu']);
                          emailExp.add(i.data()['expediteur']);
                           
                        }
                      
                    }
                    }
                    
                    print(CommunicationEtd.ID_Devoir);
                    if (emailLis.isNotEmpty) {
 
                      return Column(
                        children: [
                          Text(" \nNombre total des comptes rendus : " +Nom_fichie.length.toString(),
                          style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold,color:Colors.red),),
                          Expanded(
                            child: ListView.builder(
                              itemCount: emailLis.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                    padding: EdgeInsets.all(15),
                                    width: 400,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 15),
                                    decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 255, 255, 255),
                                        border: Border.all(
                                            color: Color.fromARGB(255, 3, 11, 244)),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(30),
                                            topRight: Radius.circular(30),
                                            bottomLeft: Radius.circular(30))),
                                    child: GestureDetector(
                                        onTap: () async {
                          
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      SfPdfViewer.network(
                                                        emailLis[index],
                                                        controller:
                                                            _pdfViewerController,
                                                      )));
                                        },
                                        child: Row(
                                          children: [
                                              Column(
                                                children: [
                                                  Container(alignment: Alignment.centerLeft,
                                                            child:
                                                           
                                                           Text("Envoyé par : "+emailExp[index]+"\n\n",style: TextStyle(color: Color.fromARGB(255, 17, 156, 40),fontWeight: FontWeight.bold))
                                                             ),
                                                ],
                                              ),
                                            Expanded(
                                              child: Row(
                                                children: [
                                                 
                                                  
                                                  Text(Nom_fichie[index],
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold)),
                                                  Icon(
                                                    Icons.picture_as_pdf_rounded,
                                                    color: Colors.red,
                                                    size: 30,
                                                  ),
                                                ],
                                              ),
                                            ),
                                      
                                          GestureDetector(onTap:() async  { 
                                                Dio dio = Dio();
                            String fileUrl = emailLis[index]; // URL du fichier à télécharger
                           String fileName=Nom_fichie[index];
                           
                          
                          
                          Directory? appDocDir = await getApplicationDocumentsDirectory();
                              String savePath = '${appDocDir.path}/$fileName';   try {
                              Response response = await dio.download(fileUrl, savePath);
                              print('Téléchargement terminé. Statut : ${response.statusCode}');
                          AwesomeDialog(context:context,
                          dialogType: DialogType.success,
                          animType: AnimType.bottomSlide,
                          title: "Sucess",
                          desc: "Téléchargement est terminer",
                          btnOkOnPress:() {},
                          ).show()  ;   
                              
                            } catch (e) {
                              print('Erreur lors du téléchargement : $e');
                            }
                                            
                                                },
                                                  //télécharger si le type est Devoir
                                             child  :   Icon(Icons.download,color: Colors.green,)
                                         ),   
                                          
                          
                          
                                          ],
                                        )
                                        
                                        )
                                        );
                              },
                            ),
                          ),
                        ],
                      );
                    }

                    return
                     Center(child: Text("Aucun compte rendu disponible",style: TextStyle(color: Colors.red,fontSize: 20,fontWeight: FontWeight.bold),));
                  }),
    );
  }
}