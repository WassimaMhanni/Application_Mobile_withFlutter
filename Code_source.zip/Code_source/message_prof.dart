import 'dart:io';
import 'dart:typed_data';

import 'package:uuid/uuid.dart';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'FullScreenImage.dart';
import 'authentifierProfesseur.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

// ignore: must_be_immutable
class message_prof extends StatefulWidget {
  String modules;
  static String  nom_fichier="";
  message_prof({required this.modules});

  @override
  State<message_prof> createState() => _message_profState(modules);
}

String modules = "";

class _message_profState extends State<message_prof>  {
  
  String modules; // récupéerer email
  _message_profState(this.modules);
  String contenu = "";
  String email_input = authentifierProfesseur.email_inpu;
  List<Widget> contenu_message = [];
  List<String> contenu1 = [];
  List<String> exp_list = [];
  List<dynamic> docs = [];
  Color couleurTexte = Colors.black;
  String expediteur = "";
  ScrollController sc = ScrollController();
  PdfViewerController? _pdfViewerController;
  File? imageFile;
  bool isScrolledToBottom = false;
  String url = "";
  DocumentReference? documentRef;
  DocumentReference? documentReceiver;
   final contenu_controller=TextEditingController();
  @override
  void initState() {
    super.initState();
    
  }

//////////////////////////////online
 

  ///
  Uint8List? file;

  //////////////////file
  UploadFile() async {
    /////////pick pdf file
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      File pick = File(result.files.single.path.toString());
       file = pick.readAsBytesSync();
      // String name = DateTime.now().millisecondsSinceEpoch.toString();
      PlatformFile fil= result.files.first;
      String name=fil.name;
    message_prof.nom_fichier = name;
  
     
setState(() {
 
});
    }
   String name= message_prof.nom_fichier;
   print("wassima"+name);
      var pdfFile =
          FirebaseStorage.instance.ref().child("files").child("$name.pdf");
      UploadTask task = pdfFile.putData(file!);
      TaskSnapshot snapshot = await task;
      url = await snapshot.ref.getDownloadURL();
      if (url.isNotEmpty) {
   
        await FirebaseFirestore.instance.collection('messages').doc().set({
          'contenu': url,
          'expediteur': email_input,
          'recepteur': modules,
          'timestamp': DateTime.now(),
          'type': "document",
          'nom fichier':message_prof.nom_fichier
        });
        
      } else {
        // Gérer le cas où l'URL est vide après la récupération
        print("L'URL de téléchargement est vide.");
      }
   
    message_prof.nom_fichier="";
  }
//////////////////////////send image from gallery/////////////////////////////////

  Future getImage() async {
    ImagePicker _picker = ImagePicker();

    await _picker.pickImage(source: ImageSource.gallery).then((xFile) {
      if (xFile != null) {
        imageFile = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future getImageCamera() async {
    ImagePicker _picker = ImagePicker();

    await _picker.pickImage(source: ImageSource.camera).then((xFile) {
      if (xFile != null) {
        imageFile = File(xFile.path);
        uploadImage();
      }
    });
  }

  Future uploadImage() async {
    String fileName = Uuid().v1();
    int status = 1;

    await FirebaseFirestore.instance.collection('messages').doc(fileName).set({
      'contenu': "",
      'expediteur': email_input, //email_input
      'recepteur': modules,
      'timestamp': DateTime.now(),
      'type': "image"
    });
    /*setState(() {
      docs.add(contenu);
    });*/
    var ref =
        FirebaseStorage.instance.ref().child('images').child("$fileName.jpg");

    var uploadTask = await ref.putFile(imageFile!).catchError((error) async {
      await FirebaseFirestore.instance
          .collection('messages')
          .doc(fileName)
          .delete();

      status = 0;
    }
    
    );
  
   
    if (status == 1) {
      String imageUrl = await uploadTask.ref.getDownloadURL();

      await FirebaseFirestore.instance
          .collection('messages')
          .doc(fileName)
          .update({"contenu": imageUrl});

      print(imageUrl);
    }
   
  }

  ////////////////////////enregistrer dans la base de données///////////////////////
  List<String> messages = [];
  Future message_envoie() async {
    CollectionReference chatCollection =
        FirebaseFirestore.instance.collection('messages');
    chatCollection.add({
      'contenu': contenu,
      'expediteur': email_input, //email_input
      'recepteur': modules,
      'timestamp': DateTime.now(),
      'type': "text"
    });
   /* setState(() {
      docs.add(contenu);
    });*/
  }

////////////////////////////////////////////////////////////////////////////////

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(235, 255, 255, 255),
      appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 63, 78, 215),
          toolbarHeight: 100.0,
          // automaticallyImplyLeading: true,

          
          title: Text(modules,style: TextStyle(fontWeight: FontWeight.bold)),
              ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection("messages")
                    .orderBy("timestamp")
                    .snapshots(),
                builder: (context, snapshot) {
                 final emailList = [];
                  
                 

                  if (snapshot.hasData) {
                    final lis = snapshot.data?.docs;
                    for (var i in lis!) {
                     
                      if (email_input == i.data()["expediteur"] &&
                          modules == i.data()["recepteur"]
                          ) {
                        var contenuu = i.data()['contenu'];
                        String type1 = i.data()['type'];
                        final timestamp = i.data()["timestamp"];
                        String? nomFichier = i.data().containsKey('nom fichier')
    ? i.data()['nom fichier']
    : '';
                     //  String nom_fichie=i.data()['nom fichier'];
                      
                        emailList.add({
                          'timestamp': timestamp,
                          'type1': type1,
                          'widget': ListTile(
                            key: ValueKey(timestamp),
                            title: Container(
                              alignment: Alignment
                                  .centerRight, // Aligner le conteneur à gauche
                              child: Container(
                                  constraints: BoxConstraints(
                                    maxWidth: MediaQuery.of(context)
                                            .size
                                            .width *
                                        0.8, // Définir la largeur maximale en fonction de l'écran
                                  ),
                                  padding: EdgeInsets.all(10),
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 20, 34, 190),
                                    border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 3, 55, 244)),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30),
                                    ),
                                  ),
                                  child: (type1 == "text")
                                      ? Text(contenuu,
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white))
                                      : (type1 == "image")
                                          ? ClipRRect(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20)),
                                              child: GestureDetector(
                                                onTap: () {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (context) =>
                                                          FullScreenImage(
                                                              imageUrl:
                                                                  contenuu),
                                                    ),
                                                  );
                                                },
                                                child: CachedNetworkImage(
                                                  width: 200,
                                                  imageUrl: contenuu,
                                                  errorWidget: (context, url,
                                                          error) =>
                                                      const Icon(Icons.refresh),
                                                ),
                                              ))
                                          : (type1 == "document")
                                              ? GestureDetector(
                                                  onTap: () async {
                                                 Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder: (context) =>
                                                                    SfPdfViewer
                                                                        .network(
                                                                     contenuu,
                                                                      controller:
                                                                          _pdfViewerController,
                                                                    )));
                                                       
                                                  },
                                                  child: Column(
                                                    children: [
                                                     Text(nomFichier!,style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                                                      Icon(
                                                          Icons.picture_as_pdf_rounded,
                                                          
                                                          color: Color.fromARGB(255, 16, 168, 74)),
                                                    ],
                                                  )
                                                      )
                                              : Container()),
                            ),
                          )
                        });
                      }
                      if (email_input == i.data()["recepteur"] &&
                          modules == i.data()["expediteur"]) {
                        String conten = i.data()['contenu'];
                     //   String nom_fichier=i.data()['nom fichier'];
                        final timestamp = i.data()["timestamp"];
                        String type = i.data()['type'];
                          String? nomFichier = i.data().containsKey('nom fichier')
    ? i.data()['nom fichier']
    : '';
                        emailList.add({
                          'timestamp': timestamp,
                          'type': type,
                          'widget': ListTile(
                            key: ValueKey(timestamp),
                            title: Container(
                              alignment: Alignment
                                  .centerLeft, // Aligner le conteneur à gauche
                              child: Container(
                                  constraints: BoxConstraints(
                                    maxWidth: MediaQuery.of(context)
                                            .size
                                            .width *
                                        0.8, // Définir la largeur maximale en fonction de l'écran
                                  ),
                                  padding: EdgeInsets.all(10),
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 1, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: Color.fromARGB(255, 255, 255, 255),
                                    border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 255, 255, 255)),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30),
                                    ),
                                  ),
                                  child: type == "text"
                                      ? Text(conten,
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold))
                                      : (type == "image")
                                          ? ClipRRect(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(20)),
                                              child: GestureDetector(
                                                onTap: () {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (context) =>
                                                          FullScreenImage(
                                                              imageUrl:
                                                                  conten),
                                                    ),
                                                  );
                                                },

                                                child: CachedNetworkImage(
                                                  width: 200,
                                                  imageUrl: conten,
                                                  errorWidget: (context, url,
                                                          error) =>
                                                      const Icon(Icons.refresh),
                                                ),
                                              ))
                                          : (type == "document")
                                              ? GestureDetector(
                                                  onTap: () async {
                                                   await Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder: (context) =>
                                                                    SfPdfViewer
                                                                        .network(
                                                                    conten,
                                                                      controller:
                                                                          _pdfViewerController,
                                                                    )));
                                                        
                                                  },
                                                  child: Column(
                                                    children: [Text(nomFichier!,style: TextStyle(fontWeight: FontWeight.bold)),
                                                      Icon(
                                                          Icons.picture_as_pdf,color: Color.fromARGB(255, 205, 28, 16),),
                                                    ],
                                                  ))
                                              : Container()),
                            ),
                          )
                        });
                      }
                    }
                    ;


                  
                  }

                  if (emailList.isNotEmpty) {
                   WidgetsBinding.instance.addPostFrameCallback((_) {
  sc.animateTo(
    sc.position.maxScrollExtent,
    duration: const Duration(milliseconds: 10),
    curve: Curves.easeOut,
  );
});

                    return ListView.builder(
                        controller: sc,
                        itemCount: emailList.length,
                        itemBuilder: (context, index) {
                          final widget = emailList[index]['widget'];
                          return widget;
                        });
                  } else {
                    return Container(
                      child: Center(
                        child: Text(
                          " Bonjour 👋",
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  }
                }),
          ),
          Container(
            child: _chat(),
          )
        ],
      ),
    );
  }

/////////////////////////

  //////////////////////////
  Widget _chat() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2.1, vertical: 20),
      child: Row(
        children: [
          Expanded(
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      UploadFile();
                    },
                    icon: Icon(
                      Icons.share_sharp,
                      color: Color.fromARGB(255, 63, 78, 215),
                    ),
                  ),
                  Expanded(
                      child: TextField(controller: contenu_controller,
                    onChanged: (value) {
                      contenu = value;
                    },

                    keyboardType: TextInputType.multiline, //retour a la  ligne
                    maxLines: null,
                    decoration: InputDecoration(
                        hintText: "Tapez içi...", border: InputBorder.none),
                  )),
                  IconButton(
                    onPressed: () {
                      getImage();
                    },
                    icon: Icon(
                      Icons.image,
                      color: Color.fromARGB(255, 63, 78, 215),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      getImageCamera();
                    },
                    icon: Icon(
                      Icons.camera_alt,
                      color: Color.fromARGB(255, 63, 78, 215),
                    ),
                  )
                ],
              ),
            ),
          ),
          ////buton envoyer
          ///
          MaterialButton(
            onPressed: () {
              if (contenu.isEmpty) {
                print("vide");
              } else {
                message_envoie();
                contenu_controller.clear();
              }
            },
            minWidth: 0,
            // padding: EdgeInsets.only(left: 32),
            color: Color.fromARGB(255, 63, 78, 215),
            shape: CircleBorder(),
            child: Icon(
              Icons.send,
              color: Colors.white,
              size: 30,
            ),
          )
        ],
      ),
    );
  }

  ////////////////////////////////////////
}
