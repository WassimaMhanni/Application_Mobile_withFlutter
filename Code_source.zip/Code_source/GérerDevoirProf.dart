import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:projet_pfe/ModifierDevoir.dart';


import 'CommunicationProf.dart';
import 'DevoirPage.dart';
import 'afficherCompteRenduProf.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:firebase_storage/firebase_storage.dart';

class GererDevoirProf extends StatefulWidget {
  const GererDevoirProf({super.key});

  @override
  State<GererDevoirProf> createState() => _GererDevoirProfState();
}

class _GererDevoirProfState extends State<GererDevoirProf> {
    PdfViewerController? _pdfViewerController;
    String titre="";
    String description="";
    String date_limit="";
String nom_fiche="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(toolbarHeight: 80,backgroundColor: Colors.green,
        title: Text("Gestion des Devoirs",style: TextStyle(  fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold),),
      ),
      body:   StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Devoir")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailList = [];
                    List<dynamic> Nom_fichie = [];
                     List<dynamic> type = [];
                 List<dynamic>     emailExp = [];
                  if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      final lis = snapshot.data?.docs;
                      for (var i in lis!) {
                       //   for(int j=0;j<modules.length;j++) {
                              if ( CommunicationProf.modules_name==i.data()["Module"]
                              && i.data()["type"]=="Devoir" 
                                  ) {
                          emailList.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom fichier']);
                          type.add(i.data()['type']);
                           emailExp.add(i.data()["expediteur"] );
                        }
                      }
                 //   }
                    }
                    if (emailList.isNotEmpty) {
                      return ListView.builder(
                        itemCount: emailList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                              padding: EdgeInsets.all(15),
                              width: 400,
                              margin: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  border: Border.all(
                                      color: Color.fromARGB(255, 3, 11, 244)),
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30))),
                              child: 
                              GestureDetector(
                                  onTap: () async {
                                   

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SfPdfViewer.network(
                                                  emailList[index],
                                                  controller:
                                                      _pdfViewerController,
                                                )));
                                  },
                                  child: 
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                             
                                            Container(padding: EdgeInsets.only(left: 60),
                                              child: Text(Nom_fichie[index],
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                            Icon(
                                              Icons.picture_as_pdf_rounded,
                                              color: Colors.red,
                                              size: 30,
                                            ),
                                          ],
                                        ),
                                      ),

                                      Builder(
                                         builder: (BuildContext context) {

                                         
                                      return GestureDetector(
                                            onTap: () {
                                             
            final RenderBox iconRenderBox = context.findRenderObject() as RenderBox;
            final iconPosition = iconRenderBox.localToGlobal(Offset.zero);

            final iconSize = iconRenderBox.size;
            final position = RelativeRect.fromLTRB(
              iconPosition.dx-270,
              iconPosition.dy,
              iconPosition.dx + iconSize.width -270,
              iconPosition.dy + iconSize.height,
            );

                                              showMenu(
                                                context: context,
                                                position: position,
                                                items: [
                                                  PopupMenuItem(
                                                      child: Text("Supprimer"),
                                                      value: "Supprimer"),
                                                       PopupMenuItem(
                                                      child: Text("Modifier"),
                                                      value: "Modifier"),
                                                       PopupMenuItem(
                                                      child: Text("Afficher Les comptes rendus"),
                                                      value: " afficher Compte rendu"),
                                                 
                                                ],
                                                elevation: 8.0,
                                              ).then((value) async {
                                                // Gérer l'action sélectionnée ici
                                                if (value == "Supprimer") {
                                                  showDialog(
                                                      context: context,
                                                      builder:
                                                          (BuildContext context) {
                                                        return AlertDialog(
                                                            title: Text(
                                                                'Confirmation'),
                                                            content: Text(
                                                                'Voulez-vous vraiment supprimer ce fichier ?'),
                                                            actions: <Widget>[
                                                              TextButton(
                                                                child: Text(
                                                                    'Annuler'),
                                                                onPressed: () {
                                                                  Navigator.of(
                                                                          context)
                                                                      .pop(); // Fermer la boîte de dialogue
                                                                },
                                                              ),
                                                              TextButton(
                                                                  child: Text(
                                                                      'Supprimer'),
                                                                  onPressed:
                                                                      () async {
                                                                    // Fermer la boîte de dialogue
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop();
                                      
                                                                    String name =
                                                                        Nom_fichie[
                                                                            index];
                                      
                                                                    String
                                                                        filePath =
                                                                        'files/$name.pdf';
                                                                    await FirebaseStorage
                                                                        .instance
                                                                        .ref()
                                                                        .child(
                                                                            filePath)
                                                                        .delete();
                                                                    Fluttertoast.showToast(
                                                                                    msg: "Le devoir a été supprimé ",
                                                                                    toastLength: Toast.LENGTH_LONG,
                                                                                    gravity: ToastGravity.CENTER,
                                                                                    timeInSecForIosWeb: 1,
                                                                                    backgroundColor: Color.fromARGB(255, 143, 230, 3),
                                                                                    textColor: Colors.white,
                                                                                    fontSize: 16.0,
                                                                                  );
                                                                    await FirebaseFirestore
                                                                        .instance
                                                                        .collection(
                                                                            "Devoir")
                                                                        .where(
                                                                            "contenu",
                                                                            isEqualTo: emailList[
                                                                                index])
                                                                        .get()
                                                                        .then((QuerySnapshot
                                                                            querySnapshot) {
                                                                      querySnapshot
                                                                          .docs
                                                                          .forEach((DocumentSnapshot
                                                                              docSnapshot) {
                                                                        DocumentReference
                                                                            documentRef =
                                                                            docSnapshot
                                                                                .reference;
                                                                        documentRef
                                                                            .delete()
                                                                            .then(
                                                                                (_) async {
                                                                                    await FirebaseFirestore
                                                                        .instance
                                                                        .collection(
                                                                            "Compte_Rendu")
                                                                        .where(
                                                                            "ID_Devoir",
                                                                            isEqualTo: Nom_fichie[
                                                                                index])
                                                                        .get()
                                                                        .then((QuerySnapshot
                                                                            querySnapshot) {
                                                                      querySnapshot
                                                                          .docs
                                                                          .forEach((DocumentSnapshot
                                                                              docSnapshot) {
                                                                        DocumentReference
                                                                            documentRef =
                                                                            docSnapshot
                                                                                .reference;
                                                                        documentRef
                                                                            .delete()
                                                                            .then(
                                                                                (_) {
                                      
                                                                             
                                                                        });
                                                                         });
                                                                      });
                                                                       
                                                                    });
                                                                  });
                                                                  });
                                                         })   ]);
                                                      });
                                                }
                                                if(value=="Modifier") {
                                                    FirebaseFirestore.instance.collection("Devoir")
  .where("nom fichier", isEqualTo: Nom_fichie[index])
  .get()
  .then((QuerySnapshot querySnapshot) {
    if (querySnapshot.docs.length > 0) {
      DocumentSnapshot devoirSnapshot = querySnapshot.docs.first;
      Map<String, dynamic>? devoirData = devoirSnapshot.data()! as Map<String, dynamic>?;

    
      // Utilisez les données du devoir récupérées
    
     if (devoirData != null) {
    if (devoirData.containsKey('titre') && devoirData['titre'] != null) {
       titre = devoirData['titre'];
print(titre);
 } 
 if (devoirData.containsKey('description') && devoirData['description'] != null) {
      description = devoirData['description'];
print(description);
     
 }
if (devoirData.containsKey('date limit') && devoirData['date limit'] != null) {
     date_limit = devoirData['date limit'];
print(date_limit);
     
 }
if (devoirData.containsKey('nom fichier') && devoirData['nom fichier'] != null) {
     nom_fiche = devoirData['nom fichier'];
print(nom_fiche);
     
 }
 
 }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ModifierDevoir(
          titre: titre,
          description: description,
          dateLimite: date_limit,
          nom_fiche:nom_fiche,
        ),
      ),
    );     
 } else {
      // Le devoir n'a pas été trouvé
    }
  }); 
                                                                                              
                                    
                                                }
                                                if(value==" afficher Compte rendu") {
                                                   Navigator.push(
                                                 context,
                                                 MaterialPageRoute(
                                                                      builder: (context) => afficherCompteRenduProf(
                                                                        nom_fichier:Nom_fichie[index]
                                                                      )));
                                                }
                                              });
                                            },
                                            child:  //affiche cet incon si le type est document n'est devoir
                                            Icon(Icons.more_vert_sharp)
                                         
                                            );
                                         }
                                      ),

                                          
                                         
                                    ],
                                  )));
                        },
                      );
                    }
                    
                    return Container();
                  }
                  
                  ),
                  floatingActionButton: Container(width: 180,height: 75,
                  padding: EdgeInsets.only(bottom: 20),
                    child: FloatingActionButton(onPressed:
                     () {
                   Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DevoirPage()));
                     },
                     mini: true,
                     
                     backgroundColor: const Color.fromARGB(255, 76, 175, 79),
                       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(60.0)),
                     child: Row(
                       children: [
                        Text(" Ajouter Devoir",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
                         Icon(Icons.add),
                       ],
                     ),
                      
                     ),
                  )
    );
  }
}