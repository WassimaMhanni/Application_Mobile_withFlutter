import 'package:fluttertoast/fluttertoast.dart';
import 'package:projet_pfe/DocumentPage.dart';

import 'CommunicationProf.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
class GererDocumentProf extends StatefulWidget {
  const GererDocumentProf({super.key});

  @override
  State<GererDocumentProf> createState() => _GererDocumentProfState();
}

class _GererDocumentProfState extends State<GererDocumentProf> {
     PdfViewerController? _pdfViewerController;
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: Color.fromARGB(255, 40, 151, 255),
        title: Text("Gestion des documents",style: TextStyle(  fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold),),
      ),
      body:   StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Devoir")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailList = [];
                    List<dynamic> Nom_fichie = [];
                     List<dynamic> type = [];
                 List<dynamic>     emailExp = [];
                   if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      final lis = snapshot.data?.docs;
                      for (var i in lis!) {
                       //   for(int j=0;j<modules.length;j++) {
                              if (   CommunicationProf.modules_name==i.data()["Module"]
                              && i.data()["type"]=="document" 
                                  ) {
                          emailList.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom fichier']);
                          type.add(i.data()['type']);
                           emailExp.add(i.data()["expediteur"] );
                        }
                      }
                 //   }
                    }
                    if (emailList.isNotEmpty) {
                      return ListView.builder(
                        itemCount: emailList.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                              padding: EdgeInsets.all(15),
                              width: 400,
                              margin: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  border: Border.all(
                                      color: Color.fromARGB(255, 3, 11, 244)),
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30))),
                              child: 
                              GestureDetector(
                                  onTap: () async {
                                   

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SfPdfViewer.network(
                                                  emailList[index],
                                                  controller:
                                                      _pdfViewerController,
                                                )));
                                  },
                                  child: 
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            
                                            Container(padding: EdgeInsets.only(left: 60),
                                              child: Text(Nom_fichie[index],
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ),
                                            Icon(
                                              Icons.picture_as_pdf_rounded,
                                              color: Colors.red,
                                              size: 30,
                                            ),
                                          ],
                                        ),
                                      ),

                                      Builder(
                                        builder: (context) {
                                          return GestureDetector(
                                              onTap: () {
                                                final RenderBox iconRenderBox = context.findRenderObject() as RenderBox;
            final iconPosition = iconRenderBox.localToGlobal(Offset.zero);

            final iconSize = iconRenderBox.size;
            final position = RelativeRect.fromLTRB(
              iconPosition.dx-100,
              iconPosition.dy,
              iconPosition.dx + iconSize.width -100,
              iconPosition.dy + iconSize.height,
            );
                                                showMenu(
                                                  context: context,
                                                  position: position,
                                                  items: [
                                                    PopupMenuItem(
                                                        child: Text("supprimer"),
                                                        value: "supprimer"),
                                                       
                                                   
                                                  ],
                                                  elevation: 8.0,
                                                ).then((value) async {
                                                  // Gérer l'action sélectionnée ici
                                                  if (value == "supprimer") {
                                                    showDialog(
                                                        context: context,
                                                        builder:
                                                            (BuildContext context) {
                                                          return AlertDialog(
                                                              title: Text(
                                                                  'Confirmation'),
                                                              content: Text(
                                                                  'Voulez-vous vraiment supprimer ce fichier ?'),
                                                              actions: <Widget>[
                                                                TextButton(
                                                                  child: Text(
                                                                      'Annuler'),
                                                                  onPressed: () {
                                                                    Navigator.of(
                                                                            context)
                                                                        .pop(); // Fermer la boîte de dialogue
                                                                  },
                                                                ),
                                                                TextButton(
                                                                    child: Text(
                                                                        'Supprimer'),
                                                                    onPressed:
                                                                        () async {
                                                                      // Fermer la boîte de dialogue
                                                                      Navigator.of(
                                                                              context)
                                                                          .pop();

                                                                      String name =
                                                                          Nom_fichie[
                                                                              index];

                                                                      String
                                                                          filePath =
                                                                          'files/$name.pdf';
                                                                      await FirebaseStorage
                                                                          .instance
                                                                          .ref()
                                                                          .child(
                                                                              filePath)
                                                                          .delete();
                                                                      print(
                                                                          'Fichier supprimé avec succès de Cloud Storage');
                                                                      await FirebaseFirestore
                                                                          .instance
                                                                          .collection(
                                                                              "Devoir")
                                                                          .where(
                                                                              "contenu",
                                                                              isEqualTo: emailList[
                                                                                  index])
                                                                          .get()
                                                                          .then((QuerySnapshot
                                                                              querySnapshot) {
                                                                        querySnapshot
                                                                            .docs
                                                                            .forEach((DocumentSnapshot
                                                                                docSnapshot) {
                                                                          DocumentReference
                                                                              documentRef =
                                                                              docSnapshot
                                                                                  .reference;
                                                                          documentRef
                                                                              .delete()
                                                                              .then(
                                                                                  (_) {
                                                                            Fluttertoast.showToast(
                                                                                    msg: "Le fichier est supprimer.",
                                                                                    toastLength: Toast.LENGTH_SHORT,
                                                                                    gravity: ToastGravity.CENTER,
                                                                                    timeInSecForIosWeb: 1,
                                                                                    backgroundColor: Colors.green,
                                                                                    textColor: Colors.white,
                                                                                    fontSize: 16.0,
                                                                                  );
                                                                          });
                                                                        });
                                                                      });
                                                                    })
                                                              ]);
                                                        });
                                                  }
                                                 
                                                });
                                              },
                                              child:  //affiche cet incon si le type est document n'est devoir
                                              Icon(Icons.more_vert_sharp)
                                            
                                              );
                                        }
                                      ),

                                          
                                         
                                    ],
                                  )));
                        },
                      );
                    }
                    return Container();
                  }),
                  floatingActionButton: Container(width: 200,height: 80,
                  padding: EdgeInsets.only(bottom: 20),
                    child: FloatingActionButton(onPressed:
                     () {
                   Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DocumentPage()));
                     },
                     mini: true,
                     
                     backgroundColor: Color.fromARGB(255, 40, 151, 255),
                       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(60.0)),
                     child: Row(
                       children: [
                        Text("  Ajouter document",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15)),
                         Icon(Icons.add),
                       ],
                     ),
                      
                     ),
                  )
    );
  }
}