import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:projet_pfe/DevoirPage.dart';
import 'package:projet_pfe/authentifierProfesseur.dart';

import 'CommunicationProf.dart';

class ModifierDevoir extends StatefulWidget {
  //const ModifierDevoir({super.key});
final String titre;
  final String description;
  final String dateLimite;
  final String nom_fiche;
 ModifierDevoir({required this.titre,required this.description,required this.dateLimite,required this.nom_fiche}){}
  @override
  State<ModifierDevoir> createState() => _ModifierDevoirState(titre,description,dateLimite,nom_fiche);
}
String titre="";
String description="";
String dateLimite="";
String nom_fiche="";
class _ModifierDevoirState extends State<ModifierDevoir> {
  String titre;
String description;
String dateLimite;
String nom_fiche;

  _ModifierDevoirState(this.titre,this.description,this.dateLimite,this.nom_fiche);
  DateTime _dateTime=DateTime.now();
  Uint8List? file;
  String url="";
 String date_limit="";
 String ti="";
 String desc="";
 String date="";
 TextEditingController _dateController = TextEditingController();
 String nom_fichier="";
 @override
 void initState() {
   super.initState();
    _dateController.text=dateLimite;
 }
_selectedDate(BuildContext context) async {
 
  DateTime? newDate=await showDatePicker(context: context, 
  initialDate: _dateTime,
   firstDate: DateTime(2000), 
  lastDate: DateTime(2100));
  if(newDate==null) return;
  
  TimeOfDay? newTime= await showTimePicker(context: context,
    initialTime: TimeOfDay.now(),
    );
    if(newTime==null) return;
    final newDateTime=DateTime(newDate.year,newDate.month,newDate.day,newTime.hour,newTime.minute);
    setState(() {
      _dateTime=newDateTime;
     DateFormat formatter = DateFormat('dd/MM/yyyy HH:mm');
    _dateController.text = formatter.format(newDateTime);
 
     
  
    });
    
  
}
bool fileExists=false;
Future<bool> checkFileExists(String fileName) async {
  
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('Devoir')
      .where('nom fichier', isEqualTo: nom_fiche)
      .limit(1)
      .get();
  
  return querySnapshot.docs.isNotEmpty;
}
 UploadFile() async {
 
        
                                                                        

    /////////pick pdf file
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      File pick = File(result.files.single.path.toString());
       file = pick.readAsBytesSync();
      // String name = DateTime.now().millisecondsSinceEpoch.toString();
      PlatformFile fil= result.files.first;
      String name=fil.name;
     nom_fichier = name;
  
     
setState(() {
 
});
    }
  
  }
 

 String id="";
 update() async{

      if(file!=null) {
      var pdfFile =
          FirebaseStorage.instance.ref().child("files").child("$nom_fichier.pdf");
      UploadTask task = pdfFile.putData(file!);
      TaskSnapshot snapshot = await task;
  url = await snapshot.ref.getDownloadURL();
  
      }
     String finalUrl = url.isNotEmpty ? url : DevoirPage.url; 
   QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('Devoir')
    //  .where('contenu', isEqualTo: DevoirPage.url)
     // .where("nom fichier", isNotEqualTo: DevoirPage.nom_fichier)
     .where("nom fichier", isEqualTo: nom_fiche)
      .limit(1)
      .get();
 fileExists = await checkFileExists(nom_fichier);
  if (querySnapshot.size > 0  ) {
    // Récupérer l'ID du premier document correspondant
    id=querySnapshot.docs[0].id;
     
     print("id est"+id);
     
        String titreFinal = ti.isNotEmpty ? ti : titre; 
        String descFinal = desc.isNotEmpty ? desc : description; 
         String nom=nom_fichier.isNotEmpty ? nom_fichier :nom_fiche;
     await FirebaseFirestore.instance.collection('Devoir').doc(id).update({
  
       
          'contenu':  finalUrl,
          'expediteur': authentifierProfesseur.email_inpu,
          'timestamp': DateTime.now(),
          'type': "Devoir",
          'Module': CommunicationProf.modules_name,
          'nom fichier':nom,
          'date limit': _dateController.text,
          'titre':titreFinal, 
          "description": descFinal
          
        }); 
        if(nom_fichier.isNotEmpty ) {
        String      filePath =     'files/${nom_fiche}.pdf';
                      await FirebaseStorage
                                                                        .instance
                                                                        .ref()
                                                                        .child(
                                                                            filePath)
                                                                        .delete();
        }
         Navigator.pop(context);                                                                
          Fluttertoast.showToast(
      msg: " Les données ont été modifiées correctement ",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor:  Colors.green,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  } else {
   
   Fluttertoast.showToast(
      msg: "fichier deja existe!.",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: const Color.fromARGB(255, 255, 64, 64) ,
      textColor: Colors.white,
      fontSize: 16.0,
    ); // Aucun document trouvé avec le contenu spécifié
  }
  
 }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(toolbarHeight: 90,backgroundColor: Colors.green,
        title: Text('Modifier les éléments du devoir',style: TextStyle(fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold)),
      ),
      body: Column(
        children: [
           Container(padding: EdgeInsets.all(10),
            child: TextField(
                controller: TextEditingController(text: titre),
              decoration: InputDecoration(
               
                labelText: 'Titre du devoir',
              icon: Icon(Icons.title,color: Color.fromARGB(255, 114, 238, 5),)
              ),
                onChanged: (value) {
                  ti=value;
                }, 
            ),
          ),
         Container(padding: EdgeInsets.all(10),
            child: TextField(  
              controller: TextEditingController(text: description),
              decoration: InputDecoration(
                icon: Icon(Icons.align_horizontal_left,color: Color.fromARGB(255, 129, 238, 5)),
                labelText: 'Description'),
                  onChanged: (value) {
                  desc=value;
                }, 
            ),
          ),
          
          Container(padding: EdgeInsets.all(10),
            child: TextField(
              readOnly: true,
            controller:_dateController,
              decoration: InputDecoration(
                icon: GestureDetector(onTap: () {
                  _selectedDate(context);
                },
                  child: Icon(Icons.calendar_month_outlined,color: Color.fromARGB(255, 36, 238, 5))),
                labelText: 'Date limit'),
                 

            ),
          ),
          
         Column(
            children: [
            
            Container(
              child: nom_fichier=="" ?
              Text(nom_fiche)
            :Text(nom_fichier))
            ,
              
              Container(padding: EdgeInsets.all(10),
                child: GestureDetector(onTap: () {
                 
                   UploadFile();
                
                },
                  child: TextField(
                    enabled: false,
                    decoration: InputDecoration(
                      icon: Icon(Icons.attachment,color: Color.fromARGB(255, 114, 238, 5)),
                      labelText: 'Ajouter une pièce jointe'),
                  ),
                ),
              ),
            ],
          ),
   ElevatedButton(
            style: ElevatedButton.styleFrom(
              minimumSize: Size(150, 50),
              backgroundColor:Colors.green,
          shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20.0),
       // Modifier le rayon du border
       
    ),
  
  ),
            onPressed: () {
             
           update();
          
            },
        
            child: Text('Modifier',style:TextStyle(fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold)) 
            
          ),



        ],
      ),
    );
  }
}