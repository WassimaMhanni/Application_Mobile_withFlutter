import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'package:projet_pfe/authentifierEtudiant.dart';

import 'package:intl/intl.dart';
import 'CommunicationEtd.dart';

import 'DevoirPage.dart';
import 'afficherCompteRendu.dart';


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:firebase_storage/firebase_storage.dart';
class DevoirEtd extends StatefulWidget {
  const DevoirEtd({super.key});

  @override
  State<DevoirEtd> createState() => _DevoirEtdState();
}

class _DevoirEtdState extends State<DevoirEtd> {
      PdfViewerController? _pdfViewerController;
       Uint8List? file;
       List ComptesRendus=[];
       String formattedDateTime="";
  date_time() async {
     String apiUrl = 'http://worldtimeapi.org/api/ip';

  var response = await http.get(Uri.parse(apiUrl));
  if (response.statusCode == 200) {
    var jsonResponse = json.decode(response.body);
    String currentDateTime = jsonResponse['datetime'];
DateTime dateTime = DateTime.parse(currentDateTime);
   formattedDateTime = DateFormat('dd/MM/yyyy HH:mm').format(dateTime);
    print("Date actuelle (Système international) : $formattedDateTime");
  } else {
    print('Erreur lors de la récupération de la date actuelle.');
  }
  }
  @override
  Widget build(BuildContext context) {date_time();
    return Scaffold(
       appBar: AppBar(toolbarHeight: 80,backgroundColor: Color.fromARGB(255, 59, 121, 207),
        title: Text("Devoir",style: TextStyle(  fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold),),
      ),
  body:    StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Devoir")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailLis = [];
                    List<dynamic> Nom_fichie = [];
                    List<dynamic> emailExp = [];
              
                      List<dynamic> titre = [];
                       List<dynamic> description = [];
                         List<String> datesList = [];

                                    if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      final lis = snapshot.data?.docs;
                      for (var i in lis!) {
                           
           
                if( CommunicationEtd.prof == i.data()["expediteur"] && CommunicationEtd.modules_name==i.data()["Module"] && i.data()["type"]=="Devoir" ) {
                          emailLis.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom fichier']);
                          emailExp.add(i.data()['expediteur']);
                           titre.add(i.data()['titre']);
                           description.add(i.data()['description']);
                         String timestamp = i.data()["date limit"];
                          // DateTime dateTime = timestamp.toDate();
                            datesList.add(timestamp);
                        }
                                   
                    }
                    }
                    if (emailLis.isNotEmpty) {
 
                      return ListView.builder(
                        itemCount: emailLis.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                              padding: EdgeInsets.all(15),
                              width: 400,
                              margin: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  border: Border.all(
                                      color: Color.fromARGB(255, 3, 11, 244)),
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30))),
                              child: GestureDetector(
                                  onTap: () async {

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SfPdfViewer.network(
                                                  emailLis[index],
                                                  controller:
                                                      _pdfViewerController,
                                                )));
                                  },
                                  child: Row(
                                    children: [
                                    
                                           Expanded(
                                             child: Column( crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                
                                              
                                                           Text("Titre : "+titre[index],style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14)),
                                                           Text("Description : "+description[index],style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 15)),
                                                            Text("Date limite : "+
                                              
                                                 
                                                      datesList[index],style: TextStyle(color: Colors.red,fontWeight: FontWeight.bold,fontSize: 14)
                                            ),
                                                           Row(                      mainAxisAlignment: MainAxisAlignment.end,
                                             
                                              children: [
                                               
                                                
                                                Text(Nom_fichie[index],
                                                    style: TextStyle(
                                                      fontSize:15,
                                                      fontWeight: FontWeight.w400
                                                        )),
                                                Icon(
                                                  Icons.picture_as_pdf_rounded,
                                                  color: Colors.red,
                                                  size: 25,
                                                ),
                                                 Builder(
                                                   builder: (context) {
                                                     return GestureDetector(child: Icon(Icons.more_vert_sharp,color: Colors.green,size: 30,),
                                          onTap: () {
                                                                    final RenderBox iconRenderBox = context.findRenderObject() as RenderBox;
            final iconPosition = iconRenderBox.localToGlobal(Offset.zero);

            final iconSize = iconRenderBox.size;
            final position = RelativeRect.fromLTRB(
              iconPosition.dx-220,
              iconPosition.dy,
              iconPosition.dx + iconSize.width -220,
              iconPosition.dy + iconSize.height,
            );
  showMenu(
                                              context: context,
                                              position: position,
                                              items: [
                                                PopupMenuItem(
                                                        child: Text("Télécharger"),
                                                        value: "Télécharger"),
                                                         PopupMenuItem(
                                                          
                                                           enabled: !DateFormat("dd/MM/yyyy HH:mm").parse(formattedDateTime).isAfter(DateFormat("dd/MM/yyyy HH:mm").parse(datesList[index])),
                                                   
                                                        child: Text("Poser compte Rendu"),
                                                        value: "Poser Compte rendu"),
                                                           PopupMenuItem(
                                                        child: Text("voir compte Rendu"),
                                                        value: "voir Compte rendu"),
                                               
                                              ],
                                              elevation: 8.0,
                                            ).then((value) async {
if(value=="Télécharger") {
     Dio dio = Dio();
  String fileUrl = emailLis[index]; // URL du fichier à télécharger
 String fileName=Nom_fichie[index];
 


Directory? appDocDir = await getApplicationDocumentsDirectory();
    String savePath = '${appDocDir.path}/$fileName';   try {
    Response response = await dio.download(fileUrl, savePath);
    print('Téléchargement terminé. Statut : ${response.statusCode}');
AwesomeDialog(context:context,
dialogType: DialogType.success,
animType: AnimType.bottomSlide,
title: "Sucess",
desc: "Téléchargement est terminer",
btnOkOnPress:() {},
).show()  ;   
    
  } catch (e) {
    print('Erreur lors du téléchargement : $e');
  }
       
}
if(value=="Poser Compte rendu") {
 
    String nom_fichier="";

  FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      File pick = File(result.files.single.path.toString());
       file = pick.readAsBytesSync();
      // String name = DateTime.now().millisecondsSinceEpoch.toString();
      PlatformFile fil= result.files.first;
      String name=fil.name;
      nom_fichier = name;
  
     
setState(() {
 
});
    }  
     String name=nom_fichier; //au lieu de rédéclarer le variable   
      var pdfFile =
          FirebaseStorage.instance.ref().child("files").child("$name.pdf");
      UploadTask task = pdfFile.putData(file!);
      TaskSnapshot snapshot = await task;
    DevoirPage.url = await snapshot.ref.getDownloadURL();
  
      if ( DevoirPage.url.isNotEmpty) {
        await FirebaseFirestore.instance.collection('Compte_Rendu').doc().set({
          'contenu': DevoirPage. url,
          'expediteur': authentifierEtudiant.email_input,
          'timestamp': DateTime.now(),    
          'Module':  CommunicationEtd.modules_name,
          'nom Compte Rendu':nom_fichier, 
          "ID_Devoir" :Nom_fichie[index] 
        });
        CommunicationEtd.ID_Devoir=Nom_fichie[index];
      
 ComptesRendus=[];       
        ComptesRendus.add(nom_fichier);
        QuerySnapshot querySnapshot = await FirebaseFirestore.instance
    .collection("Devoir")
    .where("nom fichier" , isEqualTo: Nom_fichie[index])
    .limit(1)
    .get();     
 if (querySnapshot.docs.isNotEmpty) {
  DocumentSnapshot documentSnapshot = querySnapshot.docs.first;
  String documentId = documentSnapshot.id;
  print('Document ID: ${documentSnapshot.id}');


 DocumentReference documentRef=FirebaseFirestore.instance
      .collection("Devoir")
      .doc(documentId);
   documentRef.update({
  "ComptesRendus": FieldValue.arrayUnion(ComptesRendus)  })
      .then((_) {
   Fluttertoast.showToast(
                                                                                        msg: "Le compte rendu que vous avez déposé a été enregistré avec succès.",
                                                                                        toastLength: Toast.LENGTH_LONG,
                                                                                        gravity: ToastGravity.CENTER,
                                                                                        timeInSecForIosWeb: 1,
                                                                                         backgroundColor: Colors.green,
                                                                                        textColor: Colors.white,
                                                                                        fontSize: 16.0,
                                                                                      );  })
  .catchError((error) {
    print('Erreur lors de la modification du champ : $error');
  });
} else {
  print('Aucun document trouvé avec l\'ancienne valeur du champ spécifié.');
} 
 }
 
     }
 if(value=="voir Compte rendu") {
    Navigator.push(
                                               context,
                                               MaterialPageRoute(
                                builder: (context) => afficherCompteRendu(
                                  nom_fichier:Nom_fichie[index]
                                )));
 }
  }


                                             );                                         
                                          },


                                              
                                              );
                                                   }
                                                 )
                                              ],
                                                                                   ), 
                                              ],
                                                                                     ),
                                           ),
                                        
                                    
                                        
                                      
            
                                             //télécharger si le type est Devoir
                                           
                                            
                                    


                                    ],
                                  )
                                  
                                  )
                                  );
                        },
                      );
                    }
                    return Container();
                  }),
    );
  }
}