
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'EspaceEtudiant.dart';


class authentifierEtudiant extends StatefulWidget {

static  String  email_input ="";
 

  @override
  State<authentifierEtudiant> createState() => _authentifierEtudiantState();
}

class _authentifierEtudiantState extends State<authentifierEtudiant> {
  late String Module_id="";

  List<dynamic> list_module=[];
 getData() async  { 
 //

  }
  @override
  void initState() {
    super.initState();
    
  }
  
  final email_controller=TextEditingController();   //controller le  champs
   final password_controller=TextEditingController();
  String  password_input="";
 //   String  email_input="";
 
  final auth = FirebaseFirestore;
  GlobalKey<FormState> fromkey = GlobalKey<FormState>();
  validate()  {
    
      
  
    if (fromkey.currentState!.validate()) {
       /*   ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
            content: Container(
              padding: EdgeInsets.all(20),
              height: 100,
       
            decoration: BoxDecoration(
              
              color: Colors.red,
           borderRadius: BorderRadius.all(Radius.circular(20)),



            ),
              child: Text("Les données sont incorrect!!!!!!!!!!",style: TextStyle(
              fontSize: 20,
              ),) ,
              
              margin: EdgeInsets.only(bottom: 200),
            
            ),
            backgroundColor: Color.fromARGB(251, 255, 255, 255),
           
            duration: Duration(milliseconds: 1000),
          ));
        */
      
//list_module=[];

 

      affiche("Etudiant", authentifierEtudiant.email_input, password_input, 
          "Success...", EspaceEtudiant());
 
          
    } 
    
  }

/*Future affiche() async {
bool isvalide=false;
var y=0;
bool v=false;
///////////////////Etudiant
///
///
 
 await  FirebaseFirestore.instance.collection("Etudiant").get().then((value) => 
   value.docs.forEach((element) {
  if(element.data()['email']==emai && element.data()['password']==passwor) {
  // print(element.data()['email']);
 // print(element.data()['password']);
 isvalide=true;
   }
 //  print({"msg":"hh", "data":element.data()});
   }
   ),);

   
   if(!isvalide) {
    print("erreur");
   }
   else {
    Navigator.push(context, MaterialPageRoute(builder:(context) => EspaceEtudiant(),));
  print("sacces");
   }
 /* await  FirebaseFirestore.instance.collection("Etudiant").get().then((value) => 
   value.docs.forEach((element) {
   if(element.data()['email']==emai && element.data()['password']==passwor) {
    x++;
 
   }
   }
   ),);

   if(x==0) {  //n'existe pas
   FirebaseFirestore.instance.collection("Professeur").get().then((value) => 
   value.docs.forEach((element) {
  if(element.data()['email']==emai && element.data()['password']==passwor) {
   y==true;
   }
   
   }
   )
   );

     if(y==false) { 
  print("n'esxiste pas dans professeus");
     }
  else  {
Navigator.push(context, MaterialPageRoute(builder:(context) => EspaceProfesseur(),));
  print("sacces");
       
    }
   }
   else {
 Navigator.push(context, MaterialPageRoute(builder:(context) => EspaceEtudiant(),));
  print("sacces");
   };
   
   */
  ////////////////////////Professeur
   

  ///////////////////////////////////////////////////////////












 
   
 
 
 //await    FirebaseFirestore.instance.collection("Etudiant").where("email",isEqualTo: emai).where("password",isEqualTo: passwor).
 //get().then((value) {
 // value.docs.forEach((element) {  
  
 //actualisation automatique 
// Navigator.push(context, MaterialPageRoute(builder:(context) => EspaceEtudiant(),));
//});
 

//print("ee");
// });

// if(element.data()['email']==emai && element.data()['password']==passwor); {
   // print("password :${element.data()['password']}");
   //Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>EspaceEtudiant()), (route) => false);
 //enseignant
/*await    FirebaseFirestore.instance.collection("Professeur").where("email",isEqualTo: emai).where("password",isEqualTo: passwor).
 get().then((value) {
  value.docs.forEach((element) { 
 //actualisation automatique 
 // if(element.data()['email']==emai && element.data()['password']==passwor); {
   // print("password :${element.data()['password']}");
 Navigator.push(context, MaterialPageRoute(builder:(context) => EspaceProfesseur(),));
 //Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>EspaceEtudiant()), (route) => false);
//};
});

 })*/







}*/
  Future affiche  (String collection_name, String email, String password,
      String message_seccues, dynamic page_name) async {
    bool isvalide = false;

    await FirebaseFirestore.instance.collection(collection_name).get().then(
          (value) => value.docs.forEach((element) {
            if (element.data()['email']== email &&
                element.data()['password'] == password) {
              isvalide = true;
            }
          }),
        );

    if (!isvalide) {
    showDialog(
      context: context,
       builder: (context) {
         return AlertDialog(
  content: Text("Login ou mot de passe est erroné ",style: TextStyle( fontWeight: FontWeight.w300),),
         );
       },
       );
        
    } else {
 
 

//   print(list_module);



      /////////////////////////////////
      Navigator.push( 
          context,
          MaterialPageRoute(
            builder: (context) =>    page_name,
          ));
      email_controller.clear();
      password_controller.clear();
        

      print(message_seccues);
    
    }
  }


  @override
  Widget build(BuildContext context) {
    /*  return Container(
      
      child: ListView(children: [
       
        Container(
          padding: EdgeInsets.only(top: 150, left: 20, right: 20),
          child: Form(key: fromkey,
            child: Column(children: [
              TextFormField(
               style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                onChanged: (value) {
                  email_input = value;
                
                }, //récupérer la valeur saisie
                decoration: InputDecoration(
                   fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30),borderSide: BorderSide(color: Colors.white ,width: 2),),
                    labelText: "Email académique",
                    labelStyle: TextStyle(
                        fontSize: 20,
                       // fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255)),
                    prefixIcon: Icon(
                      Icons.email,
                      color: Color.fromARGB(255, 254, 254, 254),
                      size: 30,
                      
                    ),
                  
                    border: OutlineInputBorder( 
                      borderRadius: BorderRadius.circular(50),borderSide: BorderSide(color: Colors.white,width: 3)
                    )),
                     validator: (val) {
            if(val!.isEmpty) {
              return "Entrer votre Email ";
            }
            else {
              return null;
            }
          }
              ),
            ]),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 60, left: 20, right: 20),
          child: Form(key: fromkey1,
            child: Column(children: [
              TextFormField(
              style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),  
                obscureText: true,   //crypter password
          
                onChanged: (value) {
                  password_input = value;
                }, //récupérer la valeur saisie
                decoration: InputDecoration(
                    fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30),borderSide: BorderSide(color: Colors.white ,width: 2),),
                    labelText: "Mot de passe",
                 
                    labelStyle: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 255, 255)),
                    prefixIcon: Icon(
                      Icons.mail_lock,
                      color: Color.fromARGB(255, 251, 255, 254),
                      size: 40,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(50),
                    )),
    validator: (val1) {
            if(val1!.isEmpty) {
              return "Entrer votre Mot de passe ";
            }
            else {
              return null;
            }
          }


              ),

            ]),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 30, left: 20, right: 20),
          child: Center(
            child: ElevatedButton(
              onPressed: validate,
                 
                   
              //  affiche("Etudiant", email_input, password_input,page_principale(),
                //    "Success...", EspaceEtudiant());
               
              
              child: 
              /////////////////////////////////////////////////////////////////
           //   icon: Icon(Icons.arrow_forward_sharp),
               Text("Sign In"),
              style: ElevatedButton.styleFrom(foregroundColor: Colors.black,
                  minimumSize: Size(300, 50),
                  backgroundColor: Color.fromARGB(255, 253, 253, 253),
                  //  padding: EdgeInsets.only(top: 10)
                  //  onPrimary: Colors.red,
                  textStyle:
                      TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                  //  animationDuration: Duration(microseconds: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  )),
            ),
          ),
        ),
      ]),
    );*/
    /////////////////////////////////
   
    return Container( 
      child: ListView(children: [
        Container(
          padding: EdgeInsets.only(top: 150, left: 20, right: 20),
          // Padding(padding: EdgeInsets.all(20),
          child: Center(
              child: Form(
                  key: fromkey,
                  child: Column(
                    children: <Widget>[
                      TextFormField( 
                        controller: email_controller,
                          style: TextStyle(
                              color: Color.fromARGB(255, 10, 2, 70), fontWeight: FontWeight.bold),
                          onChanged: (value) {
                            authentifierEtudiant.email_input = value;
                          },
                          decoration: InputDecoration(
                              fillColor: Colors.white,
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Color.fromARGB(255, 10, 2, 70), width: 2),
                              ),
                              labelText: "Email académique",
                              labelStyle: TextStyle(
                                  fontSize: 15,
                                  // fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 17, 66, 151),),
                              prefixIcon: Icon(
                                Icons.email,
                                color:Color.fromARGB(255, 17, 66, 151),
                                size: 25,
                              ),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(50),
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 17, 66, 151),width: 3))),
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "Entrer votre Email";
                            } else {
                              return null;
                            }
                          }),
                      ///////////////////////////////////////////////////
                      Padding(padding: EdgeInsets.only(top: 30)),
                      TextFormField(controller: password_controller,
                          obscureText: true,
                          style: TextStyle(
                              color: Color.fromARGB(255, 10, 2, 70), fontWeight: FontWeight.bold),
                          onChanged: (value) {
                            password_input = value;
                          },
                          decoration: InputDecoration(
                              fillColor: Colors.white,
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Color.fromARGB(255, 10, 2, 70), width: 2),
                              ),
                              labelText: "Mot de passe",
                              labelStyle: TextStyle(
                                  fontSize: 15,
                                  // fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 17, 66, 151),),
                              prefixIcon: Icon(
                                Icons.lock_person,
                                color: Color.fromARGB(255, 17, 66, 151),
                                size: 30,
                              ),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(50),
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 17, 66, 151), width: 3))),
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "Entrer votre Mot de passe";
                            } else {
                              return null;
                            }
                          }),
                      //////////////////////////////////////////////////
                      Padding(
                        padding: EdgeInsets.only(top: 40),
                        child: Center(
                          child: ElevatedButton.icon(
                            label: Text("Se connecter"),
                            style: ElevatedButton.styleFrom(
                                foregroundColor: Color.fromARGB(255, 255, 255, 255),
                                minimumSize: Size(300, 50),
                                backgroundColor:
                                    Color.fromARGB(255, 17, 66, 151),
                                //  padding: EdgeInsets.only(top: 10)
                                //  onPrimary: Colors.red,
                                textStyle: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                )),
                            icon: Icon(Icons.arrow_forward_sharp),
                            //////////////
                            onPressed: validate,
  
                            /////////////////////////////////////////////////////////////////
                          ),
                        ),
                      )
                      ////
                    ],
                  ))),
        ),
        ////////////////////
      ]),
    );
  }
}
