


import 'page_principale.dart';
import 'package:flutter/material.dart';
//import 'package:share_plus/share_plus.dart';
import 'package:lottie/lottie.dart';

class login extends StatelessWidget {
 
   

  @override
  Widget build(BuildContext context) {

    return Scaffold( body:  Stack(children :[
       Container( padding: EdgeInsets.only(top: 100),
        child: Lottie.asset('assets/bwPoKn8CuT.json'),

    ),
 // Positioned.fill(child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 50,sigmaY: 55),
     //  )
     //  ),
      
   // SafeArea(child: Container(padding: EdgeInsets.all(20),
    //  child: Text("Welcome To My App",style: TextStyle(fontFamily: "Poppins",fontSize: 30,fontWeight: FontWeight.bold,height: 2,color: Color.fromARGB(255, 168, 68, 255)),)
    //  ,)
     // ),
      Center(
        child: GestureDetector(child:   //fonctionne 'let start'
             Container(padding:EdgeInsets.only(top: 200,left: 10) 
             ,
             child:ElevatedButton.icon(
                            label: Text("Commencer"),
                            style: ElevatedButton.styleFrom(
                                foregroundColor: Color.fromARGB(255, 255, 255, 255),
                                minimumSize: Size(200, 42),
                                backgroundColor:
                                    Color.fromARGB(255, 22, 70, 152),
                                //  padding: EdgeInsets.only(top: 10)
                                //  onPrimary: Colors.red,
                                textStyle: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                )),
                            icon: Icon(Icons.arrow_forward_sharp),
                            //////////////
                            onPressed:() {
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>page_principale()));
                            },
  
                            /////////////////////////////////////////////////////////////////
                          ),
             
             ),
             
          ),
      ),
      ]
      ),
    );    
  
    
   
  }
}
 