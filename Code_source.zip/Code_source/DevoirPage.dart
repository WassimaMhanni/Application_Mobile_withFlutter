import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:projet_pfe/CommunicationProf.dart';
import 'authentifierProfesseur.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
class DevoirPage extends StatefulWidget {
  const DevoirPage({super.key});
 static   String url = "";
 static String nom_fichier="";
 static  String name="";
 static List<String> fileUrls = [];
 static List<String> fileName = [];
  @override
  State<DevoirPage> createState() => _DevoirPageState();
}

class _DevoirPageState extends State<DevoirPage> {
TextEditingController _dateController = TextEditingController();
   String email_input=authentifierProfesseur.email_inpu;
    String date_limit="";
 String contenu="";
 String description="";
        File? imageFile;
TextEditingController titreController = TextEditingController();
TextEditingController descriptionController = TextEditingController();
TextEditingController dateController = TextEditingController();
 List<dynamic> docs = [];
  Uint8List? file;
   bool fileExists =false;
  @override
void dispose() {
  // Annuler les minuteries ou disposer des animations ici
  super.dispose();
}

////////////calendrie//////////////////
DateTime _dateTime=DateTime.now();
_selectedDate(BuildContext context) async {
  DateTime? newDate=await showDatePicker(context: context, 
  initialDate: _dateTime,
   firstDate: DateTime(2000), 
  lastDate: DateTime(2100));
  if(newDate==null) return;
  
  TimeOfDay? newTime= await showTimePicker(context: context,
    initialTime: TimeOfDay.now(),
    );
    if(newTime==null) return;
    final newDateTime=DateTime(newDate.year,newDate.month,newDate.day,newTime.hour,newTime.minute);
    setState(() {
      _dateTime=newDateTime;
     DateFormat formatter = DateFormat('dd/MM/yyyy HH:mm');
    _dateController.text = formatter.format(_dateTime);
 
     
  
    });
    
  
}
  UploadFile() async {
    /////////pick pdf file
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      File pick = File(result.files.single.path.toString());
       file = pick.readAsBytesSync();
      // String name = DateTime.now().millisecondsSinceEpoch.toString();
      PlatformFile fil= result.files.first;
      String name=fil.name;
      DevoirPage.nom_fichier = name;
  
     
setState(() {
 
});
    }
  
  }
   // Fonction pour vérifier si le fichier existe déjà dans la base de données
Future<bool> checkFileExists(String fileName) async {
  if(DevoirPage.nom_fichier.isEmpty) {
         Fluttertoast.showToast(
      msg: "veuillez choisir  le fichier.",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('Devoir')
      .where('nom fichier', isEqualTo: DevoirPage.nom_fichier)
      .where("Module", isEqualTo: CommunicationProf.modules_name)
      .limit(1)
      .get();
  
  return querySnapshot.docs.isNotEmpty;
}
     enregistrer_file () async {

      String name=DevoirPage.nom_fichier;
      print(name);
       fileExists = await checkFileExists(name);
       if (fileExists) {
    
     Fluttertoast.showToast(
      msg: "Le fichier déjà existe",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
     
    } 
    else {
      var pdfFile =
          FirebaseStorage.instance.ref().child("files").child("$name.pdf");
      UploadTask task = pdfFile.putData(file!);
      TaskSnapshot snapshot = await task;
    DevoirPage.url = await snapshot.ref.getDownloadURL();
  
      if ( DevoirPage.url.isNotEmpty) {
        await FirebaseFirestore.instance.collection('Devoir').doc().set({
          'contenu': DevoirPage. url,
          'expediteur': email_input,
          'timestamp': DateTime.now(),
          'type': "Devoir",
          'Module': CommunicationProf.modules_name,
          'nom fichier':DevoirPage.nom_fichier,
          'date limit': _dateController.text ,
          'titre':contenu, 
          "description": description
          
        }); 
        Navigator.pop(context);
       Fluttertoast.showToast(
      msg: "Le devoir a été ajouté avec succès ",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Color.fromARGB(255, 64, 215, 69),
      textColor: Colors.white,
      fontSize: 16.0,
    );
        
  /*      setState(() {
          docs.add(contenu);
        });*/
      } else {
        // Gérer le cas où l'URL est vide après la récupération
      Fluttertoast.showToast(
      msg: "URL du téléchargement est vide .",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Color.fromARGB(255, 244, 203, 54),
      textColor: const Color.fromARGB(255, 36, 36, 36),
      fontSize: 16.0,
    );
      }
    }
 DevoirPage.nom_fichier="";
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(toolbarHeight: 90,backgroundColor:Colors.green,
        title: Text('Créer devoir',style: TextStyle(fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold)),
      ),

  body: Column(
        children: [
          Container(padding: EdgeInsets.all(10),
            child: TextField(
               controller: titreController,
              decoration: InputDecoration(
               
                labelText: 'Titre du devoir',
              icon: Icon(Icons.title,color: Color.fromARGB(255, 59, 238, 5),)
              ),
                 onChanged: (value) {
                      contenu = value;
                    },
            ),
          ),
          Container(padding: EdgeInsets.all(10),
            child: TextField(
              decoration: InputDecoration(
                icon: Icon(Icons.align_horizontal_left,color: Color.fromARGB(255, 59, 238, 5)),
                labelText: 'Description'),
                 onChanged: (value) {
                      description = value;
                    },
            ),
          ),
            Container(padding: EdgeInsets.all(10),
            child: TextField(controller: _dateController,
              decoration: InputDecoration(
                icon: GestureDetector(onTap: () {
                  _selectedDate(context);
                },
                  child: Icon(Icons.calendar_month_outlined,color:Color.fromARGB(255, 59, 238, 5))),
                labelText: 'Date limite'),
                 onChanged: (value) {
                      date_limit = value;
                    },

            ),
          ),
          Column(
            children: [
            
            Text(DevoirPage.nom_fichier),
              
              Container(padding: EdgeInsets.all(10),
                child: GestureDetector(onTap: () {
                 
                   UploadFile();
                
                },
                  child: TextField(
                    enabled: false,
                    decoration: InputDecoration(
                      icon: Icon(Icons.attachment,color: Color.fromARGB(255, 59, 238, 5)),
                      labelText: 'Ajouter une pièce jointe'),
                  ),
                ),
              ),
            ],
          ),
          // Ajoutez d'autres champs de saisie pour les autres informations du devoir
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              minimumSize: Size(150, 50),
              backgroundColor:Colors.green,
          shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20.0),
       // Modifier le rayon du border
       
    ),
  
  ),
            onPressed: () {
          if(_dateController.text.isNotEmpty) {enregistrer_file();}
            else {
               Fluttertoast.showToast(
      msg: "Entrez la date limite du devoir, s'il vous plaît!",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
     
            }
         
            
            },
            child: Text('Créer',style:TextStyle(fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold)) 
            
          ),
        ]

    )
    );
  }
}