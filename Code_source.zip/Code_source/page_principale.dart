import 'package:flutter/material.dart';

import 'authentifierEtudiant.dart';
import 'authentifierProfesseur.dart';

class page_principale extends StatelessWidget {
  const page_principale({super.key});

  @override
  Widget build(BuildContext context) {
    List<Color> CoureColor = [
      //pour la coleur
      Color.fromARGB(182, 235, 244, 239),
      Color.fromRGBO(20, 121, 105, 0.98),
    
    ];
    List<String> Coursetitle = [
      //pour le titre
      "Etudiant",
      "Professeur",
    
    ];
    List<dynamic> pages = [
      //pages
      authentifierEtudiant(),
      authentifierProfesseur(),
     
    ];
    List<String> courseImage = [
      //pour spécifier l'image
      "assets/etudi.png",
      "assets/professeur.jpeg",
     
    ];

    return Scaffold( backgroundColor: Color.fromARGB(255, 255, 255, 255),
      appBar: AppBar(backgroundColor: Color.fromARGB(255, 17, 66, 151),
      toolbarHeight: 80,
      ),
      body:  SingleChildScrollView(scrollDirection: Axis.vertical,
  
      child: Column(
        
      
    children :[
      //  color: Colors.white, //création du container
        //child: ListView(scrollDirection: Axis.vertical, children: [
          for (var i = 0;
              i < 2;
              i++) //pour éviter du création 3 container du méme donnéé;
            GestureDetector(
                onTap: () {
                  //Fonctionnement du clique(pase mziwna)
                  showDialog(    //page de dialog
                      context: context,builder: (context) 
                   => Center(
                              child: Container(
                            height: 520,
                            width: 500,
                            margin: EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                                color: Color.fromARGB(255, 255, 255, 255),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(40))),
                            child: Scaffold(
                              backgroundColor: Colors.transparent,

                              body:
                                  pages[i], //afficher la page authentifier.dart
                            ),
                          ))); //showGeneralDialog
                }, //fin de la fonction onTap()

                child: Center(
                  child: Container(
                 //   padding: EdgeInsets.all(3),
                    margin: EdgeInsets.symmetric(vertical: 50),
                    height: 200,
                    width: 300,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(blurRadius: 5, color: Colors.black)
                        ]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 150,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color: CoureColor[i],
                          ),
                          child: Image.asset(courseImage[i]),
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Center(
                              child: Column(
                            children: [
                              Text(
                                Coursetitle[i],
                                style: TextStyle(color: Colors.black,
                                    fontSize: 20, fontWeight: FontWeight.bold),
                                    
                              )
                            ],
                          )),
                        )
                      ],
                    ),
                  ),
                ))
   ] )));
  }
}
