import 'dart:math';


import 'package:projet_pfe/authentifierEtudiant.dart';
import 'package:projet_pfe/login.dart';
import 'CommunicationEtd.dart';
import 'package:flutter/material.dart';


import 'package:cloud_firestore/cloud_firestore.dart';

class EspaceEtudiant extends StatefulWidget {
  @override
  State<EspaceEtudiant> createState() => _EspaceEtudiantState();
}

class _EspaceEtudiantState extends State<EspaceEtudiant> {
  String email_input = authentifierEtudiant.email_input;
  List<dynamic> list_module = [];
  


  _EspaceEtudiantState();
  List<dynamic> modules_names = [];
String id_filiere="";
String nom_filiere="";
//////////////////////fermer session//////////////////////*
///
///////////////////////////FONCTION AFFICHER les modules d'un étudiant
  Future<void> getData() async {
   
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("Etudiant")
        .where("email", isEqualTo: email_input)
        .get();
    setState(() {
      list_module = querySnapshot.docs.first.get("Modules");
      id_filiere=querySnapshot.docs.first.get("id_fi");
    });
 
    if (list_module.length != 0) {
      for (int i = 0; i < list_module.length; i++) {
        final documentSnapshot = await FirebaseFirestore.instance
            .collection('Module')
            .doc(list_module[i])
            .get();
        final data = documentSnapshot.data();

        if (data != null && data.containsKey("nom_module")) {
          setState(() {
            modules_names.add(data["nom_module"]);
          });
        }
      }
    }
     final documentSnapshot = await FirebaseFirestore.instance
            .collection('Filiere')
            .doc(id_filiere)
            .get();
        final data = documentSnapshot.data();
         if (data != null && data.containsKey("type_f")) {
          setState(() {
            nom_filiere=data["type_f"];
          });
        }
        
  }

  
  void main1() async {
  
    await getData();
    // await getMessage();
   
  }

  @override
  void initState() {
    super.initState();
    main1();

  }
 
  Color generateRandomColor() {
 List<Color> colors = [
    Color.fromARGB(255, 255, 177, 9),
    Colors.yellow,
    Color.fromARGB(103, 14, 220, 165),
    Color.fromRGBO(118, 255, 59, 1),
 
  ];

  // Sélectionner une couleur aléatoire à partir de la liste
  Color randomColor = colors[Random().nextInt(colors.length)];

  return randomColor;
}
  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(90.0), // here the desired height
          child: AppBar(
            title: Container(margin: EdgeInsets.only(top: 10),
              child: Text("Espace Etudiant ",style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Merienda-VariableFont_wght',fontSize: 25))),
            centerTitle: true, //centrer le titre
            // shape:BeveledRectangleBorder(borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30),bottomRight: Radius.circular(36))),
            backgroundColor: Color.fromARGB(255, 63, 78, 215),
        
          )),
      drawer: Drawer(
          child: SingleChildScrollView(
              //kaddir scrooll
              child: Column(
        children: [
          UserAccountsDrawerHeader(
            currentAccountPicture: Container(//padding: EdgeInsets.all(20),
              child: CircleAvatar(
              
                 maxRadius: 50,
                child:  Icon(Icons.account_circle,size: 30,)
                                        
                                        
              ),
            ),
            
             accountEmail:Text("Filière:  "+nom_filiere,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15),),
             accountName: 
              Padding(padding: EdgeInsets.only(bottom: 5),
          child:   Text(email_input,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
         
            ),
              ),

        
        
          ListTile(
            title: Text("Accueil "),
            leading: Icon(Icons.home, color: Color.fromARGB(255, 17, 66, 151),),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EspaceEtudiant(),
                  ));
            },
          ),
          
        /*  ListTile( 
            title: Text("Agenda"),
            leading: Icon(Icons.calendar_month_outlined,
                color: Color.fromARGB(255, 17, 66, 151),),
            onTap: () async {
       Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AgendaDate()));
                      
            
  
            },

          ),*/
        
          Divider(
            color: Color.fromARGB(69, 0, 0, 0),
          ),
          ListTile(
              title: Text(
            "Inscrit",
            style: TextStyle(
              color: Color.fromARGB(255, 158, 158, 158),
            ),
          )
                
          ),
          
    for(int i=0;i<modules_names.length;i++) 
    Row(
      children: [
        Container(padding: EdgeInsets.only(left: 10),
          child: CircleAvatar(maxRadius: 15,
            
            child:  Text( modules_names[i] .substring(0, 1) .toUpperCase(),
                                              style: TextStyle(
                                                 color: Colors.white),
                                            ),
          ),
        ),
        Container(padding: EdgeInsets.all(20),
          child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        CommunicationEtd(list_module: list_module[i]),
                  ));
            },
            child: Text(modules_names[i],style: TextStyle(fontWeight: FontWeight.bold),)))
      ],
    ),

         
          Divider(
            color: Color.fromARGB(69, 0, 0, 0),
          ),
       
          ListTile(
            title: Text("Déconnecter"),
            leading:
                Icon(Icons.login_outlined, color: Color.fromARGB(255, 17, 66, 151),),
            onTap: ()  {

          
               Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                      login()
                  ));
             
               
           
            }, //icon partager
          ),
        ],
      ))),

      body: ListView(children: [
        for (int i = 0; i < modules_names.length; i++)
          GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        CommunicationEtd(list_module: list_module[i]),
                  ));
            },
            child: Container(
              height: 120,
              color: generateRandomColor(),
              child: Center(
                  child: Text(
                '${modules_names[i]}',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Merienda-VariableFont_wght'),
              )),
              margin: EdgeInsets.all(40),
              //      decoration: BoxDecoration(borderRadius:BorderRadius.circular(20)),
            ),
          )
      ]),
       //icon Add
    );

    // ignore: dead_code

////////////////////
  }
   
}
