

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:projet_pfe/G%C3%A9rerDevoirProf.dart';
import 'package:projet_pfe/G%C3%A9rerDocumentProf.dart';



import 'package:projet_pfe/authentifierProfesseur.dart';




import 'message_prof.dart';


// ignore: must_be_immutable
class CommunicationProf extends StatefulWidget {
  static String modules_name = "";
  String list_module;
  static List<String> modules = [];
  CommunicationProf({required this.list_module});

  @override
  State<CommunicationProf> createState() =>
      _CommunicationProfState(list_module);
}

String list_module = "";

class _CommunicationProfState extends State<CommunicationProf>
    with SingleTickerProviderStateMixin {
  // ignore: unused_field
  Animation<double>? _animation;
  
  String list_module;
  _CommunicationProfState(this.list_module);
   ScrollController sc = ScrollController();


  bool isScrolledToBottom = false;
  List<String> modules = [];
   final contenu_controller=TextEditingController();
/////////////////Enregistrer dans la  base de donnée//////////////////////////////
  List<String> messages = [];
  String contenu = "";
  String email_input = authentifierProfesseur.email_inpu;
  String expediteur = "";
  String messag = "";
  String type = "";
  Timestamp time = Timestamp.now();
  List<Timestamp> timestamps = [
    Timestamp.now(),
    Timestamp.fromDate(DateTime(2022, 1, 1)),
    Timestamp.fromMillisecondsSinceEpoch(1654321000000),

    // Ajoutez d'autres timestamps selon vos besoins
  ];
  Future message_envoie() async {
    CollectionReference chatCollection =
        FirebaseFirestore.instance.collection('messages');
    chatCollection.add({
      'contenu': contenu,
      'expediteur': email_input, //email_input
      'timestamp': Timestamp.now(),
      'module': CommunicationProf.modules_name,
    });
   
  }

/////////////////////////////////////////////////////////////////////////////////
 

  //////////////////télécharger////////////////////

  ///////////////récupéerer le nom du module
  Future getModule() async {
    final documentSnapshot = await FirebaseFirestore.instance
        .collection('Module')
        .doc(list_module)
        .get();
    final data = documentSnapshot.data();

    if (data != null && data.containsKey("nom_module")) {
      setState(() {
        CommunicationProf.modules_name = (data["nom_module"]);
      });
    }
  }
  String prof="";

  ///////////////////////////////////Récupérer les etudiant les les professeurs///////////////////////////////////////////////////
  Future getdd() async {
    await FirebaseFirestore.instance
        .collection("Professeur")
        .where("Modules", arrayContains: list_module)
        .get()
        .then((QuerySnapshot querySnapshot1) {
      querySnapshot1.docs.forEach((doc1) {
        print(doc1.get("email"));
        prof=doc1.get("email");
        setState(() {
          modules.add(doc1.get("email"));
           CommunicationProf. modules.add(doc1.get("email"));
        });
      });
    });

    await FirebaseFirestore.instance
        .collection("Etudiant")
        .where("Modules", arrayContains: list_module)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        print(doc.get("email"));
        setState(() {
          modules.add(doc.get("email"));
          CommunicationProf.modules.add(doc.get("email"));
        });
      });
    });
  }

  ///////////////////////////////////////////////////////////////////////////////////////////
  void main1() async {
    await getModule();
    await getdd();
  }

  @override
  void initState() {
   

    super.initState();


    main1();
  }

  String fileUrl = "";
  int index = 0;
  @override
  Widget build(BuildContext context) {
    
    return DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 70,
            centerTitle: false,
            titleSpacing: 30,
            title: Text(
              CommunicationProf.modules_name,
              style: TextStyle(
                  letterSpacing: 3,
                  fontFamily: 'Merienda-VariableFont_wght',
                  fontWeight: FontWeight.bold,
                  fontSize: 25,
                  color: Color.fromARGB(255, 255, 255, 255)),
            ),
            backgroundColor: Color.fromARGB(255, 63, 78, 215),
            bottom: TabBar(
                onTap: (value) {
                  setState(() {
                    index = value;
                  });
                },
                tabs: [
                  Tab(
                    icon: Icon(
                      Icons.chat,
                      color: Colors.white,
                      size: 20,
                    ),
                    text: 'Discussions',
                  ),
                  Tab(
                    icon: Icon(
                      Icons.animation_sharp,
                      color: Colors.white,
                    ),
                    text: 'Travaux',
                  ),
                  Tab(
                    icon: Icon(
                      Icons.group_outlined,
                      color: Colors.white,
                    ),
                    text: 'Participants',
                  ),
                ]),
          ),
          body: TabBarView(
            children: [
              //chno aytektebb fch t cliquer ela tabs bar
              ////////////////////////////////// TAB   1////////////////////////////////////////////
              Column(
                children: [
                  Expanded(
                    child: StreamBuilder(stream: FirebaseFirestore.instance.collection("messages").orderBy('timestamp').snapshots(),
                       
                      builder: (context, snapshot) {
                         List<dynamic> emailList = [];
                         List<dynamic> emailExp = [];
                           List<DateTime> datesList = [];
                           if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                          if (snapshot.hasData) {
                            final lis = snapshot.data?.docs;
                          for (var i in lis!) {
    if (modules.contains(i.data()["expediteur"]) && CommunicationProf.modules_name == i.data()["module"]) {
        emailList.add(i.data()['contenu']);
        Timestamp timestamp = i.data()["timestamp"];

                                  DateTime dateTime = timestamp.toDate();
        datesList.add(dateTime);
        emailExp.add(i.data()["expediteur"]);
    }
}

                        }

                          if(emailList.isNotEmpty) {//print(datesList);
         WidgetsBinding.instance.addPostFrameCallback((_) {
  sc.animateTo(
    sc.position.maxScrollExtent,
    duration: const Duration(milliseconds: 10),
    curve: Curves.easeOut,
  );
});

                            return ListView.builder( controller: sc,
                              itemCount: emailList.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                    padding: EdgeInsets.all(15),
                                    width: 400,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 15),
                                    decoration: BoxDecoration(
                                        color: Color.fromARGB(255, 255, 255, 255),
                                        border: Border.all(
                                            color: Color.fromARGB(255, 3, 11, 244)),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(30),
                                            topRight: Radius.circular(30),
                                            bottomLeft: Radius.circular(30))),
                                          child: Column(
                                            children: [
                                                Container(alignment: Alignment.centerLeft,
                                                  child: emailExp[index]== prof ? Text(emailExp[index],style: TextStyle(color: Colors.red,fontWeight: FontWeight.bold))
                                                  :Text(emailExp[index],style: TextStyle(color: Color.fromARGB(255, 13, 164, 35),fontWeight: FontWeight.bold))
                                                  ),
                                              Center(child: Text(emailList[index],style: TextStyle(fontWeight: FontWeight.bold))),
                                                Container(
                                alignment: Alignment.bottomLeft,
                                child: Center(
                                  child:
                                   Text(
                                    "\n" +
                                        DateFormat('dd-MM-yyyy HH:mm')
                                                      .format(datesList[index]),
                                  ),
                                )),
                                            ],
                                          ),
                  
                  
                  
                                ) ;
                              },
                            );
                          }
                  
                  
                            return Container();
                      }
                      
                      ),
                  ),
                    Container(child: _chat(),)
                ],
              ),

         
         
         
              //////////////////////////////////////////TAB2////////////////////////////////////////
                     Column(
                     mainAxisSize: MainAxisSize.min,
                     children: [
                      Container(padding: EdgeInsets.only(top: 100,left: 10,right: 10),
                      child: ElevatedButton(onPressed: () {
                         Navigator.push(
                                               context,
                                               MaterialPageRoute(
                                builder: (context) => GererDevoirProf()
                                ));
                      }, 
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                       padding: EdgeInsets.only(left: 80,right: 80,top: 20,bottom: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))
                      ),
                      child: Text("Gérer devoir",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      ),
                      ),
                      Container(padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                      child: ElevatedButton(onPressed: () {
                            Navigator.push(
                                               context,
                                               MaterialPageRoute(
                                builder: (context) => GererDocumentProf()
                                ));
                      }, 
                        style: ElevatedButton.styleFrom(
                         
                          backgroundColor: Color.fromARGB(255, 40, 151, 255),
                        padding: EdgeInsets.only(left: 30,right: 30,top: 20,bottom: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40))
                      ),
                      child: Text("Gérer document de cours",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      ),
                      )
                     
                     ],
                     ),
            

              //////// TAB3     ///////////////////////////////////////
                  ListView(
                  children: [
                    for (int i = 0; i < modules.length; i++)
                      /////A discuter////////////
                      GestureDetector(
                          onTap: () {
                           Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                     (message_prof(modules: modules[i]))));
                          },
                          /////A discuter////////////
                          child: StreamBuilder(
                              stream: FirebaseFirestore.instance
                                  .collection("messages")
                                  .orderBy('timestamp', descending: true)
                                  .snapshots(),
                              builder: (context, snapshot) {
                                if (!snapshot.hasData) {}
                                if (snapshot.connectionState ==
                                    ConnectionState.waiting) {
                               //   return CircularProgressIndicator(); // Indicateur de chargement en attendant les données
                                }
                                if (snapshot.hasData &&
                                    snapshot.data!.docs.isNotEmpty) {
                                  final data = snapshot.data?.docs;
                                  final list = [];
                                  if (data != null && data.first.exists) {
                                    for (var i1 in data) {
                                      if (authentifierProfesseur.email_inpu==
                                                  i1.data()["expediteur"] &&
                                              modules[i] ==
                                                  i1.data()["recepteur"] ||
                                          authentifierProfesseur.email_inpu ==
                                                  i1.data()["recepteur"] &&
                                             modules[i] ==
                                                  i1.data()["expediteur"]) {
                                        messag = i1.data()['contenu'];
                                        type = i1.data()['type'];
                                        time = i1.data()['timestamp'];
                                        list.add(messag);
                                        list.add(type);
                                        list.add(time);
                                      } else {
                                        messag = "";
                                      }
                                    }

                                    if (list.isNotEmpty) {
                                      messag = list[0];
                                      type = list[1];
                                      time = list[2];
                                    }
                                    ;
                                    //   print(messag);
                                    print(type);
                                  }
                                } else {
                                  Text("");
                                }
                                return Card(
                                  child: ListTile(
                                    leading: modules[i]==prof ? 
                                     CircleAvatar(
                                     
                                       backgroundColor: Colors.red,   
                                      child: 
                                      Text( 
                                       modules[i]
                                            .substring(0, 1)
                                            .toUpperCase(),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,color: const Color.fromARGB(255, 255, 255, 255)),
                                      )
                                    ):
                                     CircleAvatar(
                                     
                                      backgroundColor: Color.fromARGB(255, 21, 211, 46),
                                      child: 
                                      Text( 
                                       modules[i]
                                            .substring(0, 2)
                                            .toUpperCase(),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,color: const Color.fromARGB(255, 255, 255, 255)),
                                      )
                                    )
                                    ,
                                    title:modules[i]==prof ? 
                                    Text(
                                      modules[i],
                                      style: TextStyle(fontSize: 16,color: Colors.deepOrange,fontWeight: FontWeight.bold),
                                    ):
                                    Text(
                                     modules[i],
                                      style: TextStyle(fontSize: 15,color:Color.fromARGB(141, 19, 19, 19),),
                                    ),
                                    subtitle: type == "text" && messag != ""
                                        ? Row(
                                            children: [
                                              Expanded(child: Text(messag)),
                                              Text(DateFormat('HH:mm')
                                                  .format(time.toDate()))
                                            ],
                                          )
                                        : type == "image" && messag != ""
                                            ? Row(
                                                children: [
                                                  Expanded(
                                                      child: Row(
                                                    children: [
                                                      Text("photo"),
                                                      Icon(Icons.photo),
                                                    ],
                                                  )),
                                                  Text(DateFormat('HH:mm')
                                                      .format(time.toDate()))
                                                ],
                                              )
                                            : type == "document" && messag != ""
                                                ? Row(
                                                    children: [
                                                      Expanded(
                                                        child: Row(
                                                          children: [
                                                            Text("document"),
                                                            Icon(Icons
                                                                .picture_as_pdf_outlined),
                                                          ],
                                                        ),
                                                      ),
                                                      Text(DateFormat('HH:mm')
                                                          .format(
                                                              time.toDate()))
                                                    ],
                                                  )
                                                : Container(),
                                  ),
                                );
                              })),
                  ],
                )
            ],
          ),
         
        ));
  }

  Widget _chat() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2.1, vertical: 20),
      child: Row(
        children: [
          Expanded(
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              child: Row(
                children: [
                  Padding(padding: EdgeInsets.only(left: 30)),
                  Expanded(
                      child: TextField(controller: contenu_controller,
                    onChanged: (value) {
                       contenu = value;
                    },

                    keyboardType: TextInputType.multiline, //retour a la  ligne
                    maxLines: null,
                    decoration: InputDecoration(
                        hintText: "Partagez à votre classe ...",
                        border: InputBorder.none),
                  )),
                ],
              ),
            ),
          ),
          ////buton envoyer
          ///
          MaterialButton(
              onPressed: () {
              
              if(contenu.isNotEmpty) {
   message_envoie();
   contenu_controller.clear();
  
              }
              if(contenu.isEmpty) {
                print("d");
              }
           
              },
              minWidth: 0,
              // padding: EdgeInsets.only(left: 32),

              color: Color.fromARGB(210, 19, 225, 225),
              child: Text(
                "publier",
                style: TextStyle(color: Colors.white),
              ))
        ],
      ),
    );
  }
}
