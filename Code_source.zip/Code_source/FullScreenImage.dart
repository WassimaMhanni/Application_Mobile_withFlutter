

import 'package:flutter/material.dart';

class FullScreenImage extends StatelessWidget {
   final String imageUrl;

  FullScreenImage({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
  
     return Scaffold(
      body: GestureDetector(
        onTap: () {
          Navigator.pop(context); // Ferme la page ou le dialogue en plein écran lorsqu'on clique dessus
        },
        child: Container(
          color: Colors.black, // Couleur de fond
          child: Center(
            child: Image.network(
              imageUrl,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }
}