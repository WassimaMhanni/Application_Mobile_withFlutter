import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:projet_pfe/CommunicationProf.dart';
import 'authentifierProfesseur.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:file_picker/file_picker.dart';

class DocumentPage extends StatefulWidget {
  const DocumentPage({super.key});
 static   String url = "";
 static String nom_fichier="";
 static  String name="";
 static List<String> fileUrls = [];
 static List<String> fileName = [];
  @override
 State<DocumentPage> createState() => _DocumentPageState();
}

class _DocumentPageState extends State<DocumentPage> {

   String email_input=authentifierProfesseur.email_inpu;
    String date_limit="";
 String contenu="";
 String description="";
        File? imageFile;

 List<dynamic> docs = [];
  Uint8List? file;
  @override
void dispose() {
  // Annuler les minuteries ou disposer des animations ici
  super.dispose();
}

////////////calendrie//////////////////

  UploadFile() async {
    /////////pick pdf file
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      File pick = File(result.files.single.path.toString());
       file = pick.readAsBytesSync();
      // String name = DateTime.now().millisecondsSinceEpoch.toString();
      PlatformFile fil= result.files.first;
      String name=fil.name;
      DocumentPage.nom_fichier = name;
  
     
setState(() {
 
});
    }
  
  }
   
    Future<bool> checkFileExists(String fileName) async {
  if(DocumentPage.nom_fichier.isEmpty) {
         Fluttertoast.showToast(
      msg: "veuillez choisir  le fichier.",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('Devoir')
      .where('nom fichier', isEqualTo: DocumentPage.nom_fichier)
      .limit(1)
      .get();
  
  return querySnapshot.docs.isNotEmpty;
}
     enregistrer_file () async {

      String name=DocumentPage.nom_fichier;
      print(name);
       bool fileExists = await checkFileExists(name);
       if (fileExists) {
    
     Fluttertoast.showToast(
      msg: "Le fichier existe déjà.",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0,
    );
     
    } 
    else {
      
      var pdfFile =
          FirebaseStorage.instance.ref().child("files").child("$name.pdf");
      UploadTask task = pdfFile.putData(file!);
      TaskSnapshot snapshot = await task;
    DocumentPage.url = await snapshot.ref.getDownloadURL();
  
      if ( DocumentPage.url.isNotEmpty) {
        await FirebaseFirestore.instance.collection('Devoir').doc().set({
          'contenu': DocumentPage. url,
          'expediteur': email_input,
          'timestamp': DateTime.now(),
          'type': "document",
          'Module': CommunicationProf.modules_name,
          'nom fichier':DocumentPage.nom_fichier,
          'titre':contenu, 
          "description": description
          
        }); 
        Navigator.pop(context);
       Fluttertoast.showToast(
     msg: "Le document a été ajouté avec succès ",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Color.fromARGB(255, 64, 215, 69),
      textColor: Colors.white,
      fontSize: 16.0,
    );
        
  /*      setState(() {
          docs.add(contenu);
        });*/
      } else {
        // Gérer le cas où l'URL est vide après la récupération
      Fluttertoast.showToast(
      msg: "URL du téléchargement est vide .",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 1,
      backgroundColor: Color.fromARGB(255, 244, 203, 54),
      textColor: const Color.fromARGB(255, 36, 36, 36),
      fontSize: 16.0,
    );
      }
    }
 DocumentPage.nom_fichier="";
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(toolbarHeight: 80,backgroundColor: Color.fromARGB(255, 40, 151, 255),
        title: Text('Créer un document de cours',style: TextStyle(fontFamily: 'Merienda-VariableFont_wght'),),
      ),

  body: Column(
        children: [
          Container(padding: EdgeInsets.all(10),
            child: TextField(
              
              decoration: InputDecoration(
                 
                labelText: 'Titre du document',
                
              icon: Icon(Icons.title,color: Colors.deepOrange)
              ),
                onChanged: (value) {
                  contenu=value;
                },
            ),
          ),
          Container(padding: EdgeInsets.all(10),
            child: TextField(
              decoration: InputDecoration(
                icon: Icon(Icons.align_horizontal_left,color: Colors.deepOrange),
                labelText: 'Description'),
                onChanged: (value) {
                  description=value;
                },
            ),
          ),
          
          Column(
            children: [
            
            Text(DocumentPage.nom_fichier),
              
              Container(padding: EdgeInsets.all(10),
                child: GestureDetector(onTap: () {
                 
                   UploadFile();
                
                },
                  child: TextField(
                    enabled: false,
                    decoration: InputDecoration(
                      icon: Icon(Icons.attachment,color: Colors.deepOrange),
                      labelText: 'Ajouter une pièce jointe'),
                  ),
                ),
              ),
            ],
          ),
          // Ajoutez d'autres champs de saisie pour les autres informations du devoir
          ElevatedButton(
           style: ElevatedButton.styleFrom(
              minimumSize: Size(150, 50),
              backgroundColor:Color.fromARGB(255, 40, 151, 255),
          shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20.0),// Couleur du texte du bouton
  ),),
            onPressed: () {
              
            enregistrer_file();

               // Revenir à la page précédente
                
            
            },
           child: Text('Créer',style:TextStyle(fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold)) 
            
          ),
        ]

    )
    );
  }
}