
import 'package:flutter/material.dart';
import 'login.dart';
import 'package:firebase_core/firebase_core.dart';


void main() async  {
WidgetsFlutterBinding.ensureInitialized(); //fait la sychronisation avant de lançer le projet
  await Firebase.initializeApp();

  //initialiser firebase
runApp(MaterialApp(
  debugShowCheckedModeBanner:false,    //Kat7ayed dk 'icon debug'
  home: login(),
 //theme: ThemeData(primarySwatch: (Colors.green)), //couleur du agenda
));
}
  
  



