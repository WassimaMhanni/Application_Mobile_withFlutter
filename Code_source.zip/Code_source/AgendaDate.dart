import 'package:table_calendar/table_calendar.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class AgendaDate extends StatefulWidget {
  const AgendaDate({super.key});

  @override
  State<AgendaDate> createState() => _AgendaDateState();
}

class _AgendaDateState extends State<AgendaDate> {

  ValueNotifier<DateTime> _selectedDate = ValueNotifier<DateTime>(DateTime.now());

List<DateTime> _limitDates = [];
Future<List<String>> getDateFromFirestore() async {
final QuerySnapshot snapshot = await FirebaseFirestore.instance
      .collection('Devoir')
      .get();

  final List<String> dates = [];

  for (final DocumentSnapshot document in snapshot.docs) {
final Map<String, dynamic>? data = document.data() as Map<String, dynamic>?;
            if (data != null && data.containsKey('date limit')) {
      final dateString = document['date limit'] as String;
      dates.add(dateString);
    }
  }
print(dates);
  return dates;
}
  @override
  void initState() {
    super.initState();
_loadDatesFromFirestore();

  }
   Future<void> _loadDatesFromFirestore() async {
   final dates = await getDateFromFirestore();
  final dateFormat = DateFormat('dd/MM/yyyy');

  final List<DateTime> limitDates = [];
  for (final dateString in dates) {
    if(dates.isNotEmpty) {
    final date = dateFormat.parse(dateString);
    limitDates.add(date);
  }
  }
  setState(() {
    _limitDates = limitDates;
  });

  print(dates);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.blueGrey,
        title: Text("Agenda"),
        leading: Icon(
          Icons.calendar_month_outlined,
          color: Colors.white,
        ),
      ),
      body:FutureBuilder<void>(
        future: getDateFromFirestore(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            // Afficher un indicateur de chargement pendant que les dates sont récupérées
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des dates"));
          } else {
    
           
      
      return  TableCalendar(
          focusedDay: _selectedDate.value,
  firstDay: DateTime(1900), // Le premier jour de la semaine n'est pas limité
  lastDay: DateTime(2100),
  selectedDayPredicate: (date) {
  final selectedDateFormatted = DateFormat('dd/MM/yyyy').format(date);
  final selectedDate = DateFormat('dd/MM/yyyy').parse(selectedDateFormatted);
  return _limitDates.any((date) => date.isAtSameMomentAs(selectedDate));
},
       onDaySelected: (date, events) {
            _selectedDate.value = date;
          
          },
           calendarBuilders: CalendarBuilders(
            todayBuilder: (context, date, _) {
 //  final isDateInFirestore = _limitDates.any((limitDate) => limitDate.isAtSameMomentAs(date));
  final isDateInFirestore = _limitDates.any((limitDate) => limitDate.isAtSameMomentAs(date));
 

             return Container(
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: isDateInFirestore==true ? Colors.green : Color.fromARGB(255, 48, 181, 214),
    ),
                child: Center(
                  child: Column(
                    children: [
                       if (isDateInFirestore==true) Text(
            'Date limite',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
            ),
          ),
                      Text(
                        '${date.day}',
                        style: TextStyle(
                          color: isDateInFirestore ? Colors.black : Color.fromARGB(255, 252, 252, 252),
                        ),
                      ),
                       
                    ],
                  ),

                ),
              );
              
            },



          ),  
        );
          }
        }
      )
  
    );
  }
}