


import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';


import 'package:projet_pfe/authentifierEtudiant.dart';
import 'CommunicationEtd.dart';

import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

// ignore: must_be_immutable
class afficherCompteRendu extends StatefulWidget {
//  const afficherCompteRendu({super.key});
 String nom_fichier;
 afficherCompteRendu({required this.nom_fichier}) {}
  @override
  State<afficherCompteRendu> createState() => _afficherCompteRenduState(nom_fichier);
}
String nom_fichier="";
class _afficherCompteRenduState extends State<afficherCompteRendu> {
  String nom_fichier;
  _afficherCompteRenduState(this.nom_fichier);
  PdfViewerController? _pdfViewerController;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Voici votre compte rendu"),
      toolbarHeight: 80,backgroundColor: const Color.fromARGB(255, 26, 91, 205),
      ),
    body:  StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Compte_Rendu")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailLis = [];
                    List<dynamic> Nom_fichie = [];
                    List<dynamic> emailExp = [];
                      if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      final lis = snapshot.data?.docs;
                      for (var i in lis!) {
                           
                              if 
                              (
                                authentifierEtudiant.email_input== i.data()["expediteur"] 
                             
                                  ) {
                                    if(CommunicationEtd.modules_name==i.data()["Module"] && nom_fichier==i.data()["ID_Devoir"]) {
                          emailLis.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom Compte Rendu']);
                          emailExp.add(i.data()['expediteur']);
                        
                        }
                                  }  
                    }
                    }
                    print(CommunicationEtd.ID_Devoir);
                    if (emailLis.isNotEmpty) {
 
                      return ListView.builder(
                        itemCount: emailLis.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                              padding: EdgeInsets.all(15),
                              width: 400,
                              margin: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  border: Border.all(
                                      color: Color.fromARGB(255, 3, 11, 244)),
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30))),
                              child: GestureDetector(
                                  onTap: () async {

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SfPdfViewer.network(
                                                  emailLis[index],
                                                  controller:
                                                      _pdfViewerController,
                                                )));
                                  },
                                  child: Row(
                                    children: [
                                        Column(
                                          children: [
                                            Container(alignment: Alignment.centerLeft,
                                                      child:
                                                     
                                                     Text(emailExp[index]+"\n\n",style: TextStyle(color: Color.fromARGB(255, 17, 156, 40),fontWeight: FontWeight.bold))
                                                       ),
                                          ],
                                        ),
                                      Expanded(
                                        child: Row(
                                          children: [
                                           
                                            
                                            Text(Nom_fichie[index],
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold)),
                                            Icon(
                                              Icons.picture_as_pdf_rounded,
                                              color: Colors.red,
                                              size: 30,
                                            ),
                                          ],
                                        ),
                                      ),
            
                                          
                                    


                                    ],
                                  )
                                  
                                  )
                                  );
                        },
                      );
                    }
                    return Container();
                  }),
    );
  }
}