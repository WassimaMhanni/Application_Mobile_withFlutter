import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'EspaceProfesseur.dart';
class authentifierProfesseur extends StatefulWidget {
  static  String  email_inpu ="";
 // const authentifierProfesseur({super.key});

  @override
  State<authentifierProfesseur> createState() => _authentifierProfesseurState();
}
 // authentifierEtudiant authentifierEtud=new authentifierEtudiant();
class _authentifierProfesseurState extends State<authentifierProfesseur> {
    String password_input="";
    final email_controller=TextEditingController();
   final password_controller=TextEditingController();
 GlobalKey<FormState> fromkey = GlobalKey<FormState>();
  void validate() {
    if (fromkey.currentState!.validate()) {


       /*   ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
            content: Container(
              padding: EdgeInsets.all(20),
              height: 100,
       
            decoration: BoxDecoration(
              
              color: Colors.red,
           borderRadius: BorderRadius.all(Radius.circular(20)),



            ),
              child: Text("Les données sont incorrect!!!!!!!!!!",style: TextStyle(
              fontSize: 20,
              ),) ,
              
              margin: EdgeInsets.only(bottom: 200),
            
            ),
            backgroundColor: Color.fromARGB(251, 255, 255, 255),
           
            duration: Duration(milliseconds: 1000),
          ));
        */
      


      affiche("Professeur", authentifierProfesseur.email_inpu, password_input, 
          "Success...", EspaceProfesseur());

          
    } 
  }



 Future affiche(String collection_name, String email, String password,
       String message_seccues, dynamic page_name) async {
    bool isvalide = false;

    await FirebaseFirestore.instance.collection(collection_name).get().then(
          (value) => value.docs.forEach((element) {
            if (element.data()['email'] == email &&
                element.data()['password'] == password) {
              isvalide = true;
            }
          }),
        );

    if (!isvalide) {
      showDialog(
      context: context,
       builder: (context) {
         return AlertDialog(
  content: Text("Login ou mot de passe est erroné ",style: TextStyle( fontWeight: FontWeight.w300),),
         );
      }  );
    } else {
      Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => page_name,
          ));
       
           email_controller.clear();
          password_controller.clear();
      print(message_seccues);
    }
       
 
  }
  


  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView(children: [
        Container(
          padding: EdgeInsets.only(top: 150, left: 20, right: 20),
          // Padding(padding: EdgeInsets.all(20),
          child: Center(
              child: Form(
                  key: fromkey,
                  child: Column(
                    children: <Widget>[
                      TextFormField( 
                        controller: email_controller,
                          style: TextStyle(
                              color: Color.fromARGB(255, 10, 2, 70), fontWeight: FontWeight.bold),
                          onChanged: (value) {
                            authentifierProfesseur.email_inpu = value;
                          },
                          decoration: InputDecoration(
                              fillColor: Colors.white,
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Color.fromARGB(255, 10, 2, 70), width: 2),
                              ),
                              labelText: "Email académique",
                              labelStyle: TextStyle(
                                  fontSize: 15,
                                  // fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 10, 2, 70)),
                              prefixIcon: Icon(
                                Icons.email,
                                color:Color.fromARGB(255, 10, 2, 70),
                                size: 25,
                              ),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(50),
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 10, 2, 70), width: 3))),
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "Entrer votre Email";
                            } else {
                              return null;
                            }
                          }),
                      ///////////////////////////////////////////////////
                      Padding(padding: EdgeInsets.only(top: 30)),
                      TextFormField(controller: password_controller,
                          obscureText: true,
                          style: TextStyle(
                              color: Color.fromARGB(255, 10, 2, 70), fontWeight: FontWeight.bold),
                          onChanged: (value) {
                            password_input = value;
                          },
                          decoration: InputDecoration(
                              fillColor: Colors.white,
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    BorderSide(color: Color.fromARGB(255, 10, 2, 70), width: 2),
                              ),
                              labelText: "Mot de passe",
                              labelStyle: TextStyle(
                                  fontSize: 15,
                                  // fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 10, 2, 70)),
                              prefixIcon: Icon(
                                Icons.lock_person,
                                color: Color.fromARGB(255, 10, 2, 70),
                                size: 30,
                              ),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(50),
                                  borderSide: BorderSide(
                                      color: Color.fromARGB(255, 10, 2, 70), width: 3))),
                          validator: (val) {
                            if (val!.isEmpty) {
                              return "Entrer votre Mot de passe";
                            } else {
                              return null;
                            }
                          }),
                      //////////////////////////////////////////////////
                      Padding(
                        padding: EdgeInsets.only(top: 40),
                        child: Center(
                          child: ElevatedButton.icon(
                            label: Text("Se connecter"),
                            style: ElevatedButton.styleFrom(
                                foregroundColor: Color.fromARGB(255, 255, 255, 255),
                                minimumSize: Size(300, 50),
                                backgroundColor:
                                    Color.fromARGB(255, 63, 78, 215),
                                //  padding: EdgeInsets.only(top: 10)
                                //  onPrimary: Colors.red,
                                textStyle: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                )),
                            icon: Icon(Icons.arrow_forward_sharp),
                            //////////////
                            onPressed: validate,

                            /////////////////////////////////////////////////////////////////
                          ),
                        ),
                      )
                      ////
                    ],
                  ))),
        ),
        ////////////////////
      ]),
    );



  }
}