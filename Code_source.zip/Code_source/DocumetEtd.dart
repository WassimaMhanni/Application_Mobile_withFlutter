import 'dart:io';
import 'dart:typed_data';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'CommunicationEtd.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class DocumentEtd extends StatefulWidget {
  const DocumentEtd({super.key});

  @override
  State<DocumentEtd> createState() => _DocumentEtdState();
}

class _DocumentEtdState extends State<DocumentEtd> {
      PdfViewerController? _pdfViewerController;
       Uint8List? file;
       List ComptesRendus=[];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(toolbarHeight: 80,backgroundColor: Colors.green,
        title: Text("Document de cours",style: TextStyle(  fontFamily: 'Merienda-VariableFont_wght',fontWeight: FontWeight.bold),),
      ),
  body:    StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("Devoir")
                      .orderBy('timestamp')
                      .snapshots(),
                  builder: (context, snapshot) {
                    List<dynamic> emailLis = [];
                    List<dynamic> Nom_fichie = [];
                    List<dynamic> emailExp = [];
                    
                      List<dynamic> titre = [];
                       List<dynamic> description = [];
                         if (snapshot.connectionState == ConnectionState.waiting) {
           
            return Center(child: CircularProgressIndicator());
          }  if (snapshot.hasError) {
            // Gérer les erreurs de récupération des dates depuis Firestore
            return Center(child: Text("Erreur lors du chargement des données"));
          };
                    if (snapshot.hasData) {
                      final lis = snapshot.data?.docs;
                      for (var i in lis!) {
                           
           
                if( CommunicationEtd.prof== i.data()["expediteur"] && CommunicationEtd.modules_name==i.data()["Module"] && i.data()["type"]=="document" ) {
                          emailLis.add(i.data()['contenu']);
                          Nom_fichie.add(i.data()['nom fichier']);
                          emailExp.add(i.data()['expediteur']);
                           titre.add(i.data()['titre']);
                           description.add(i.data()['description']);
                        }
                                   
                    }
                    }
                    if (emailLis.isNotEmpty) {
 
                      return ListView.builder(
                        itemCount: emailLis.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                              padding: EdgeInsets.all(15),
                              width: 400,
                              margin: EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 15),
                              decoration: BoxDecoration(
                                  color: Color.fromARGB(255, 255, 255, 255),
                                  border: Border.all(
                                      color: Color.fromARGB(255, 3, 11, 244)),
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(30),
                                      topRight: Radius.circular(30),
                                      bottomLeft: Radius.circular(30))),
                              child: GestureDetector(
                                  onTap: () async {

                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                SfPdfViewer.network(
                                                  emailLis[index],
                                                  controller:
                                                      _pdfViewerController,
                                                )));
                                  },
                                  child: Row(
                                    children: [
                                    
                                           Expanded(
                                             child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                
                                                
                                                           Text("Titre : "+titre[index],style: TextStyle(fontSize: 16),),
                                                           Text("Description : "+description[index],style: TextStyle(fontSize: 16)),
                                                               Row(  mainAxisAlignment: MainAxisAlignment.end,
                                          children: [
                                           
                                            
                                            Text(Nom_fichie[index],
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold)),
                                            Icon(
                                              Icons.picture_as_pdf_rounded,
                                              color: Colors.red,
                                              size: 20,
                                            ),
                                          
                                      
            
                                             //télécharger si le type est Devoir
                                            GestureDetector(child  :   Icon(Icons.download,color: Colors.green,),
                                              onTap:() async  { 
                                                Dio dio = Dio();
                            String fileUrl = emailLis[index]; // URL du fichier à télécharger
                           String fileName=Nom_fichie[index];
                           
                          
                          
                          Directory? appDocDir = await getApplicationDocumentsDirectory();
                              String savePath = '${appDocDir.path}/$fileName';   try {
                              Response response = await dio.download(fileUrl, savePath);
                              print('Téléchargement terminé. Statut : ${response.statusCode}');
                          AwesomeDialog(context:context,
                          dialogType: DialogType.success,
                          animType: AnimType.bottomSlide,
                          title: "Sucess",
                          desc: "Téléchargement est terminé",
                          btnOkOnPress:() {},
                          ).show()  ;   
                              
                            } catch (e) {
                              print('Erreur lors du téléchargement : $e');
                            }
                                            
                                                },
                                                  //télécharger si le type est Devoir
                                             
                                         ),   
                                          
],
                                                                               ),

                                              ],
                                                                                     ),
                                           ),
                                        
                                    
                                     
                                    ],
                                  )
                                  
                                  )
                                  );
                        },
                      );
                    }
                    return Container();
                  }),
    );
  }
}